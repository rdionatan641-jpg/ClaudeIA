-keep class com.claudeia.bot.** { *; }
-keepclassmembers class com.claudeia.bot.MainActivity$BotBridge {
    @android.webkit.JavascriptInterface <methods>;
}
