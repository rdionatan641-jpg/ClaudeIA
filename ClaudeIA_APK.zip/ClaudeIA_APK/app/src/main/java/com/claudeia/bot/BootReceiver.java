package com.claudeia.bot;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // Pode ser usado para reiniciar o bot após reboot se necessário
    }
}
