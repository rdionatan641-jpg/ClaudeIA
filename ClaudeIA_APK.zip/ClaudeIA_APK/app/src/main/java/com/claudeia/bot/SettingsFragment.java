package com.claudeia.bot;

import android.os.Bundle;
import androidx.preference.EditTextPreference;
import androidx.preference.ListPreference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreference;

public class SettingsFragment extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.preferences, rootKey);

        // Valida Stop Loss
        EditTextPreference stopLoss = findPreference("stop_loss");
        if (stopLoss != null) {
            stopLoss.setSummaryProvider(pref -> {
                String val = ((EditTextPreference) pref).getText();
                return "R$ " + (val != null && !val.isEmpty() ? val : "30") + " de perda máxima";
            });
        }

        // Valida Stop Win
        EditTextPreference stopWin = findPreference("stop_win");
        if (stopWin != null) {
            stopWin.setSummaryProvider(pref -> {
                String val = ((EditTextPreference) pref).getText();
                return "R$ " + (val != null && !val.isEmpty() ? val : "50") + " de lucro alvo";
            });
        }

        // Valor entrada
        EditTextPreference entryAmount = findPreference("entry_amount");
        if (entryAmount != null) {
            entryAmount.setSummaryProvider(pref -> {
                String val = ((EditTextPreference) pref).getText();
                return "R$ " + (val != null && !val.isEmpty() ? val : "5") + " por operação";
            });
        }
    }
}
