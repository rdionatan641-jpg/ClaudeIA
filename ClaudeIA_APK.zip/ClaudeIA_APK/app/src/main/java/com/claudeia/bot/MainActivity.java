package com.claudeia.bot;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    public static final String CHANNEL_ID = "claudeia_trades";
    private static final int NOTIF_PERM_CODE = 101;

    private WebView webView;
    private TextView tvStatus;
    private TextView tvWins;
    private TextView tvLosses;
    private TextView tvProfit;
    private TextView tvStopStatus;

    private SharedPreferences prefs;
    private boolean botRunning = false;
    private double sessionProfit = 0.0;
    private int sessionWins = 0;
    private int sessionLosses = 0;
    private int notifId = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = PreferenceManager.getDefaultSharedPreferences(this);

        // Views
        webView      = findViewById(R.id.webView);
        tvStatus     = findViewById(R.id.tvStatus);
        tvWins       = findViewById(R.id.tvWins);
        tvLosses     = findViewById(R.id.tvLosses);
        tvProfit     = findViewById(R.id.tvProfit);
        tvStopStatus = findViewById(R.id.tvStopStatus);

        createNotificationChannel();
        requestNotificationPermission();
        setupWebView();

        // Botões
        findViewById(R.id.btnStartBot).setOnClickListener(v -> startBot());
        findViewById(R.id.btnStopBot).setOnClickListener(v -> stopBot());
        findViewById(R.id.btnOpenBroker).setOnClickListener(v -> {
            webView.loadUrl("https://trade.avalonbroker.com");
            webView.setVisibility(View.VISIBLE);
        });
        findViewById(R.id.btnHideWebView).setOnClickListener(v -> {
            webView.setVisibility(View.GONE);
            Toast.makeText(this, "Bot rodando em segundo plano ✅", Toast.LENGTH_SHORT).show();
        });
    }

    // ── WebView Setup ──────────────────────────────────────────────
    private void setupWebView() {
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setCacheMode(WebSettings.LOAD_NO_CACHE);

        // Habilita debugging do WebView
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        // Interface JS → Java para receber eventos do bot
        webView.addJavascriptInterface(new BotBridge(), "AndroidBot");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url.contains("avalonbroker.com")) {
                    injectScripts();
                    tvStatus.setText("🌐 Broker conectada");
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("https://trade.avalonbroker.com");
    }

    // ── Injeção de Scripts ─────────────────────────────────────────
    private void injectScripts() {
        runOnUiThread(() -> {
            try {
                // 1. ws_interceptor (precisa rodar primeiro)
                String wsInterceptor = loadAsset("ws_interceptor.js");
                webView.evaluateJavascript(wsInterceptor, null);

                // 2. sdk-bundle
                String sdkBundle = loadAsset("sdk-bundle.js");
                webView.evaluateJavascript(sdkBundle, null);

                // 3. sdk-bridge
                String sdkBridge = loadAsset("sdk-bridge.js");
                webView.evaluateJavascript(sdkBridge, null);

                // 4. content.js principal
                String contentJs = loadAsset("content.js");
                webView.evaluateJavascript(contentJs, null);

                // 5. Injetamos bridge para capturar eventos e enviar ao Android
                injectAndroidBridge();

            } catch (IOException e) {
                tvStatus.setText("❌ Erro ao carregar scripts: " + e.getMessage());
            }
        });
    }

    private void injectAndroidBridge() {
        // Intercepta TRADE_RESULT e Stop Loss/Win via interface Java
        String bridge = "javascript:(function() {\n" +
            "  // Intercepta pushTradeToDashboard via chrome.runtime (simulado)\n" +
            "  var _origDispatch = window.dispatchEvent.bind(window);\n" +
            "  \n" +
            "  // Observa o window.__cia_push__ via polling de resultado\n" +
            "  window.__androidTradeCallback = function(isWin, amount, profit, direction, asset) {\n" +
            "    if (window.AndroidBot) {\n" +
            "      AndroidBot.onTradeResult(isWin ? 'WIN' : 'LOSS', amount, profit, direction, asset);\n" +
            "    }\n" +
            "  };\n" +
            "  \n" +
            "  // Patch addResultRow para notificar Android\n" +
            "  // O content.js chama pushTradeToDashboard que usa chrome.runtime.sendMessage\n" +
            "  // Shimamos chrome.runtime para capturar\n" +
            "  if (!window.chrome) window.chrome = {};\n" +
            "  if (!window.chrome.runtime) window.chrome.runtime = {};\n" +
            "  if (!window.chrome.storage) {\n" +
            "    window.chrome.storage = { local: {\n" +
            "      get: function(keys, cb) {\n" +
            "        var result = {};\n" +
            "        if (typeof keys === 'string') keys = [keys];\n" +
            "        keys.forEach(function(k) {\n" +
            "          var v = localStorage.getItem('cia_' + k);\n" +
            "          if (v !== null) result[k] = JSON.parse(v);\n" +
            "        });\n" +
            "        cb(result);\n" +
            "      },\n" +
            "      set: function(obj, cb) {\n" +
            "        Object.keys(obj).forEach(function(k) {\n" +
            "          localStorage.setItem('cia_' + k, JSON.stringify(obj[k]));\n" +
            "        });\n" +
            "        if (cb) cb();\n" +
            "      }\n" +
            "    }};\n" +
            "  }\n" +
            "  \n" +
            "  var _origSendMsg = window.chrome.runtime.sendMessage;\n" +
            "  window.chrome.runtime.sendMessage = function(msg, cb) {\n" +
            "    if (msg && msg.__cia_push__ && msg.type === 'TRADE_RESULT' && msg.data) {\n" +
            "      var d = msg.data;\n" +
            "      if (window.AndroidBot) {\n" +
            "        AndroidBot.onTradeResult(d.result, String(d.amount), String(d.profit), d.direction, d.asset);\n" +
            "      }\n" +
            "    }\n" +
            "    if (_origSendMsg) _origSendMsg.call(window.chrome.runtime, msg, cb);\n" +
            "  };\n" +
            "  \n" +
            "  console.log('[AndroidBridge] Instalado com sucesso');\n" +
            "})();";
        webView.evaluateJavascript(bridge, null);
    }

    private String loadAsset(String filename) throws IOException {
        InputStream is = getAssets().open(filename);
        byte[] buffer = new byte[is.available()];
        is.read(buffer);
        is.close();
        return new String(buffer, StandardCharsets.UTF_8);
    }

    // ── Bot Start/Stop ─────────────────────────────────────────────
    private void startBot() {
        botRunning = true;
        sessionProfit = 0.0;
        sessionWins = 0;
        sessionLosses = 0;
        updateScoreUI();
        tvStatus.setText("🤖 Bot ativo — operando...");
        tvStopStatus.setText("Stop Loss: R$ " + prefs.getString("stop_loss", "30") +
                             "  |  Stop Win: R$ " + prefs.getString("stop_win", "50"));

        // Inicia serviço foreground para rodar em background
        Intent serviceIntent = new Intent(this, BotForegroundService.class);
        startForegroundService(serviceIntent);

        // Dispara startSession() no content.js
        webView.evaluateJavascript(
            "javascript: (function() {" +
            "  var btn = document.querySelector('#btn-start, [id*=\"start\"], .btn-start');" +
            "  if (btn) { btn.click(); return 'clicked'; }" +
            "  if (typeof startSession === 'function') { startSession(); return 'startSession'; }" +
            "  return 'no_button';" +
            "})();",
            value -> runOnUiThread(() -> {
                if (value != null && !value.contains("no_button")) {
                    tvStatus.setText("🤖 Sessão iniciada!");
                }
            })
        );

        Toast.makeText(this, "Bot iniciado! Pode minimizar o app ✅", Toast.LENGTH_LONG).show();
    }

    private void stopBot() {
        botRunning = false;
        tvStatus.setText("⏹ Bot parado");

        Intent serviceIntent = new Intent(this, BotForegroundService.class);
        stopService(serviceIntent);

        webView.evaluateJavascript(
            "javascript: (function() {" +
            "  var btn = document.querySelector('#btn-stop, [id*=\"stop\"], .btn-stop');" +
            "  if (btn) { btn.click(); return 'clicked'; }" +
            "  if (typeof stopSession === 'function') { stopSession(); return 'stopped'; }" +
            "  return 'no_button';" +
            "})();", null
        );
    }

    // ── Bridge Java ← JavaScript ───────────────────────────────────
    public class BotBridge {

        @JavascriptInterface
        public void onTradeResult(String result, String amount, String profit, String direction, String asset) {
            boolean isWin = "WIN".equals(result);
            double profitVal = 0;
            double amountVal = 0;
            try {
                profitVal = Double.parseDouble(profit);
                amountVal = Double.parseDouble(amount);
            } catch (NumberFormatException ignored) {}

            sessionProfit += profitVal;
            if (isWin) sessionWins++; else sessionLosses++;

            final double finalProfit = sessionProfit;
            final int wins = sessionWins;
            final int losses = sessionLosses;
            final boolean win = isWin;
            final String dir = direction;
            final String assetName = asset;
            final double profitFinal = profitVal;

            runOnUiThread(() -> {
                updateScoreUI();
                checkStopConditions();
            });

            // Notificação nativa
            sendTradeNotification(win, dir, assetName, amountVal, profitFinal);
        }

        @JavascriptInterface
        public String getStopLoss() {
            return prefs.getString("stop_loss", "30");
        }

        @JavascriptInterface
        public String getStopWin() {
            return prefs.getString("stop_win", "50");
        }
    }

    // ── Stop Loss / Stop Win ───────────────────────────────────────
    private void checkStopConditions() {
        if (!botRunning) return;

        double stopLoss = -Math.abs(Double.parseDouble(prefs.getString("stop_loss", "30")));
        double stopWin  = Math.abs(Double.parseDouble(prefs.getString("stop_win", "50")));

        if (sessionProfit <= stopLoss) {
            stopBot();
            tvStatus.setText("🛑 STOP LOSS atingido — R$ " + String.format("%.2f", sessionProfit));
            sendStopNotification("🛑 STOP LOSS", "Limite de perda atingido! Bot parado. Resultado: R$ " + String.format("%.2f", sessionProfit));
            Toast.makeText(this, "STOP LOSS atingido! Bot encerrado.", Toast.LENGTH_LONG).show();
        } else if (sessionProfit >= stopWin) {
            stopBot();
            tvStatus.setText("🏆 STOP WIN atingido — R$ +" + String.format("%.2f", sessionProfit));
            sendStopNotification("🏆 STOP WIN", "Meta de lucro atingida! Bot parado. Resultado: R$ +" + String.format("%.2f", sessionProfit));
            Toast.makeText(this, "STOP WIN atingido! Bot encerrado.", Toast.LENGTH_LONG).show();
        }
    }

    private void updateScoreUI() {
        tvWins.setText("✅ " + sessionWins);
        tvLosses.setText("❌ " + sessionLosses);
        String profitStr = (sessionProfit >= 0 ? "+R$ " : "R$ ") + String.format("%.2f", sessionProfit);
        tvProfit.setText(profitStr);
        tvProfit.setTextColor(getColor(sessionProfit >= 0 ? R.color.colorWin : R.color.colorLoss));
    }

    // ── Notificações ───────────────────────────────────────────────
    private void sendTradeNotification(boolean isWin, String direction, String asset, double amount, double profit) {
        String title = isWin ? "✅ WIN — " + direction : "❌ LOSS — " + direction;
        String body = asset + " | R$ " + String.format("%.2f", amount) +
                      " → " + (profit >= 0 ? "+R$ " : "R$ ") + String.format("%.2f", profit) +
                      "  |  Saldo sessão: " + (sessionProfit >= 0 ? "+R$ " : "R$ ") + String.format("%.2f", sessionProfit);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setColor(isWin ? 0xFF2ECC8A : 0xFFE05060);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(notifId++, builder.build());
    }

    private void sendStopNotification(String title, String body) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(9999, builder.build());
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID,
            "Claude IA Trades",
            NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("Notificações de Win/Loss do bot");
        channel.enableLights(true);
        channel.enableVibration(true);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_PERM_CODE);
            }
        }
    }

    // ── Menu ───────────────────────────────────────────────────────
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "⚙️ Configurações");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == 1) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
