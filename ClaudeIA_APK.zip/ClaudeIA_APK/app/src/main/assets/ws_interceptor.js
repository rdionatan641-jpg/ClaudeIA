// ── Claude IA — WS Interceptor ───────────────────────────────────────
// Runs at document_start in MAIN world (before page JS creates WebSocket)
(function() {
  if (window.__cia_ws_patched__) return;
  window.__cia_ws_patched__ = true;

  let brokerWS         = null;
  let reqId            = 10000;
  let lastRequestedAid = null;
  let lastStreamAid    = null;
  const _WS            = window.WebSocket;

  window.WebSocket = function(url, protocols) {
    const ws = protocols ? new _WS(url, protocols) : new _WS(url);

    if (url && url.includes('ws.trade.avalonbroker.com')) {
      brokerWS = ws;

      ws.addEventListener('close', function() {
        window.dispatchEvent(new CustomEvent('__cia_ws_closed__'));
      });

      ws.addEventListener('message', function(e) {
        try {
          const data = JSON.parse(e.data);
          if (!data) return;

          // Tenta extrair SSID de mensagens do servidor
          if (!window.__cia_ssid__) {
            const maybeToken = data.msg?.ssid || data.msg?.token || data.msg?.session_id || data.ssid;
            if (typeof maybeToken === 'string' && maybeToken.length > 8) {
              window.__cia_ssid__ = maybeToken;
              window.dispatchEvent(new CustomEvent('__cia_ssid__', { detail: { ssid: maybeToken } }));
            }
          }

          // ── Live candle ─────────────────────────────────────────────
          // OTC/Turbo:  size === 60  (M1 completed or updating)
          // Digital:    size === 0   (live updating candle)
          // Accept both — content.js already filters by currentActiveId
          if (data.name === 'candle-generated') {
            const msg = data.msg;
            if (!msg) return;

            // Only care about M1 candles:
            // - OTC sends size:60 for completed M1
            // - Digital sends size:0 for the live updating candle;
            //   we detect M1 by checking the candle duration (to-from ≈ 60s)
            const isM1 = msg.size === 60
              || msg.size === 0
              || (msg.to && msg.from && (msg.to - msg.from) <= 60);

            if (!isM1) return;

            const aid = msg.active_id;
            // Detect active switch from stream
            if (aid !== lastStreamAid) {
              lastStreamAid = aid;
              window.dispatchEvent(new CustomEvent('__cia_active_change__', {
                detail: { active_id: aid, source: 'stream' }
              }));
            }
            window.dispatchEvent(new CustomEvent('__cia_candle__', { detail: msg }));
          }

          // ── Historical candles ──────────────────────────────────────
          if (data.name === 'candles' && data.msg?.candles?.length) {
            // Filter M1: duration of exactly 60s
            const m1 = data.msg.candles.filter(c => {
              const dur = (c.to || 0) - (c.from || 0);
              return dur === 60 || c.size === 60;
            });
            if (m1.length) {
              m1.sort((a, b) => a.from - b.from);
              window.dispatchEvent(new CustomEvent('__cia_candles_history__', {
                detail: { candles: m1, active_id: lastRequestedAid || lastStreamAid }
              }));
            }
          }

          // ── Active map on connect ───────────────────────────────────
          // Reads BOTH turbo (OTC) and digital actives
          if (data.name === 'initialization-data' && data.msg) {
            const map = {};

            // Helper: extract actives from any namespace object
            function extractActives(namespace, assetType) {
              const actives = namespace?.actives || {};
              Object.values(actives).forEach(a => {
                if (!a.id) return;
                const raw  = a.description || a.name || '';
                const name = raw
                  .replace('front.', '')
                  .replace(/ \(OTC\)/g, '')
                  .replace(/-OTC$/g, '');
                map[a.id] = { name: name || `#${a.id}`, ticker: a.ticker, precision: a.precision || 5, assetType };
              });
            }

            // OTC/Turbo assets → 'binary'
            extractActives(data.msg.turbo,  'binary');
            // Digital assets  → 'digital'
            extractActives(data.msg.digital,'digital');
            // Blitz / binary fallbacks → 'binary'
            extractActives(data.msg.blitz,  'binary');
            extractActives(data.msg.binary, 'binary');

            if (Object.keys(map).length) {
              window.dispatchEvent(new CustomEvent('__cia_actives__', { detail: map }));
            }
          }

          // ── Server-confirmed active ─────────────────────────────────
          if (data.name === 'active-initialization-data' && data.msg?.active_id) {
            window.dispatchEvent(new CustomEvent('__cia_active_change__', {
              detail: { active_id: data.msg.active_id, source: 'server' }
            }));
          }

        } catch {}
      });

      // ── Outgoing messages — user switching asset/mode ───────────────
      const _send = ws.send.bind(ws);
      ws.send = function(raw) {
        try {
          const msg  = JSON.parse(raw);
          const name = msg?.name || '';

          // Captura SSID da autenticação da página → repassa ao SDK bridge
          if (name === 'ssid' && typeof msg.msg === 'string' && msg.msg.length > 8) {
            window.__cia_ssid__ = msg.msg;
            window.dispatchEvent(new CustomEvent('__cia_ssid__', { detail: { ssid: msg.msg } }));
          }

          if (name === 'subscribe' || name === 'subscribe-candle' || name === 'set-active-id') {
            const aid = msg.msg?.active_id || msg.msg?.actives?.[0] || msg.msg?.activeId;
            if (aid) {
              window.dispatchEvent(new CustomEvent('__cia_active_change__', {
                detail: { active_id: aid, source: 'subscribe' }
              }));
            }
          }
          if (name === 'get-candles' && msg.msg?.active_id) {
            lastRequestedAid = msg.msg.active_id;
          }
        } catch {}
        return _send(raw);
      };
    }

    return ws;
  };

  window.WebSocket.prototype = _WS.prototype;
  ['CONNECTING','OPEN','CLOSING','CLOSED'].forEach(k => { window.WebSocket[k] = _WS[k]; });

  window.__cia_ws_send = function(msgObj) {
    if (!brokerWS || brokerWS.readyState !== 1) return false;
    if (!msgObj.request_id) msgObj.request_id = String(++reqId);
    brokerWS.send(JSON.stringify(msgObj));
    return true;
  };

  window.__cia_request_candles = function(active_id, count = 10) {
    lastRequestedAid = active_id;
    const now  = Math.floor(Date.now() / 1000);
    const from = now - (count * 60) - 60;
    return window.__cia_ws_send({ name: 'get-candles', msg: { active_id, size: 60, from, to: now, count } });
  };

})();
