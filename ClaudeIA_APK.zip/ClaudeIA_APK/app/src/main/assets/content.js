(() => {
  'use strict';
  const ROOT_ID = '__claudeia3__';
  if (document.getElementById(ROOT_ID)) return;

  // ── Storage ──────────────────────────────────────────────────────
  const store = {
    get: keys => new Promise(r => chrome.storage.local.get(keys, r)),
    set: obj  => new Promise(r => chrome.storage.local.set(obj, r)),
  };

  // ── SDK state (sdk-bundle.js inicializado pelo ws_interceptor.js) ───
  let sdkReady        = false;
  let sdkUseDemo      = false; // sempre Real
  let realBalance     = 0;
  let lastTradeAmount   = 5; // atualizado a cada executeEntry
  let martingaleBase        = 5;     // valor original configurado pelo usuário
  let martingaleActive      = false;  // martingale está dobrado?
  let martingaleEnabled     = false;  // toggle liga/desliga martingale
  let martingaleSuppressSync = false; // evita loop ao atualizar inputs
  let q5ExecutingGrace    = false;  // janela de proteção após entrada (evita resetar sessão)
  let envFatalIssues    = [];
  let envScanDone     = false;
  let compatModalOpen = false;

  window.addEventListener('__cia_sdk_ready__', e => {
    sdkReady = true;
    // Notifica membros.html que o SDK conectou
    chrome.runtime.sendMessage({
      __cia_push__: true,
      type: 'SDK_CONNECTED',
      data: e.detail, // { demo: {amount,currency}, real: {amount,currency} }
    });
    const { demo, real, bonus } = e.detail;

    // Compatibilidade ampliada:
    // usa saldo real + bônus quando disponível.
    const bonusAmount =
      Number(bonus?.amount || 0) ||
      Number(real?.bonus || 0) ||
      Number(real?.bonusAmount || 0);

    const mergedRealAmount =
      Number(real?.amount || 0) + bonusAmount;

    console.log('[CIA] SDK pronto — Demo:', demo?.amount, '| Real:', real?.amount, '| Bonus:', bonusAmount);
    // Settings overlay balance
    const dEl = $('sdk-demo-val'), rEl = $('sdk-real-val');
    if (dEl && demo) dEl.textContent = `${demo.currency} ${Number(demo.amount).toFixed(2)}`;
    if (rEl && real) rEl.textContent = `${real.currency} ${mergedRealAmount.toFixed(2)}`;
    const sdkRow = $('sdk-bal-row');
    if (sdkRow) sdkRow.style.display = 'flex';
    // Painel principal — saldo Real
    const rAmt = $('bal-real-amt');
    if (rAmt && real) rAmt.textContent = `R$ ${mergedRealAmount.toFixed(2)}`;
    // Atualiza saldo real e revalida botão
    if (real || bonus) {
      realBalance = mergedRealAmount;
      const lockMsg = $('bal-lock-msg');
      if (lockMsg) lockMsg.style.display = 'none';
    }
    checkAnalyzeReady();
  });

  window.addEventListener('__cia_sdk_error__', e => {
    console.warn('[CIA] SDK erro:', e.detail?.error);
  });

  // Envia pedido de compra ao sdk-bridge.js (MAIN world) via CustomEvent
  function sdkBuy(params) {
    return new Promise(resolve => {
      const requestId = Date.now() + '-' + Math.random();

      function onResult(e) {
        if (e.detail?.requestId !== requestId) return;
        window.removeEventListener('__cia_sdk_result__', onResult);
        resolve(e.detail);
      }

      window.addEventListener('__cia_sdk_result__', onResult);
      window.dispatchEvent(new CustomEvent('__cia_sdk_buy__', { detail: { requestId, ...params } }));

      setTimeout(() => {
        window.removeEventListener('__cia_sdk_result__', onResult);
        resolve({ ok: false, error: 'SDK timeout (10s)' });
      }, 10000);
    });
  }

  // ── WebSocket events (dispatched by ws_interceptor.js) ────────────
  // ws_interceptor.js runs at document_start in MAIN world and fires
  // CustomEvents on window. We listen here in the content script world.

  // ── Active map & candle tracking ─────────────────────────────────
  let activeMap        = {};
  let currentActiveId  = null;
  const candlesByActive = {};  // active_id → Map<from, candle>
  const MAX_CANDLES    = 100;

  // Sorted array helper
  function getCandlesSorted(aid) {
    if (!candlesByActive[aid]) return [];
    return [...candlesByActive[aid].values()].sort((a, b) => a.from - b.from);
  }

  // Upsert: overwrite existing candle with same `from` (handles live updates)
  function upsertCandle(aid, candle) {
    if (!candlesByActive[aid]) candlesByActive[aid] = new Map();
    candlesByActive[aid].set(candle.from, candle);
    // Trim oldest if over limit
    if (candlesByActive[aid].size > MAX_CANDLES) {
      const oldest = getCandlesSorted(aid)[0];
      if (oldest) candlesByActive[aid].delete(oldest.from);
    }
  }

  // Listen for WS messages relayed from ws_interceptor.js
  window.addEventListener('__cia_actives__', e => {
    activeMap = e.detail;
    // Re-apply asset type for current active in case it arrived late
    if (currentActiveId && activeMap[currentActiveId]?.assetType) {
      currentAssetType = activeMap[currentActiveId].assetType;
      console.log('[Claude IA] Asset type (late):', currentAssetType);
    }
  });

  window.addEventListener('__cia_active_change__', e => {
    const aid    = e.detail.active_id;
    const source = e.detail.source || 'unknown';
    if (aid && aid !== currentActiveId) {
      console.log('[Claude IA] Active change:', aid, 'via', source);
      currentActiveId = aid;
      onActiveChange(aid);
    }
  });

  // ── WS event handlers ─────────────────────────────────────────────

  // Historical candles batch (response to get-candles request)
  window.addEventListener('__cia_candles_history__', e => {
    const { candles, active_id } = e.detail;
    if (!candles.length) return;
    const aid = active_id || currentActiveId;
    if (!aid) return;

    // Bootstrap currentActiveId if still unknown
    if (!currentActiveId) {
      currentActiveId = aid;
      onActiveChange(aid);
    }

    // Store all candles for this asset
    candles.forEach(c => upsertCandle(aid, {
      active_id: aid, size: 60,
      open: c.open, close: c.close, min: c.min, max: c.max,
      from: c.from, to: c.to, id: c.id,
    }));

    // Only re-render if this is still the active asset
    if (aid !== currentActiveId) return;
    recomputeTrend(aid);
    renderCandleHistory(aid);
    if (lastCandle) { updateCandleBar(lastCandle); updateCandleTicker(lastCandle); }
  });

  // Live M1 candle (OTC: size 60; digital em tempo real: size 0 — mesmo critério do ws_interceptor)
  function isM1CandleMsg(c) {
    if (!c) return false;
    if (c.size === 60 || c.size === 0) return true;
    if (c.to != null && c.from != null && (c.to - c.from) <= 60) return true;
    return false;
  }

  window.addEventListener('__cia_candle__', e => {
    const c   = e.detail;
    const aid = c.active_id;
    if (!isM1CandleMsg(c)) return;

    // Always store for all assets
    upsertCandle(aid, c);

    // Bootstrap: if no active detected yet via subscribe/server, use first candle
    if (currentActiveId === null) {
      currentActiveId = aid;
      onActiveChange(aid);
      return;
    }

    // Only update UI for the currently selected asset
    if (aid !== currentActiveId) return;
    onCandleUpdate(c);
  });

  function onActiveChange(aid) {
    if (lockedAssetId && aid !== lockedAssetId && q5Running) {
      console.log('[FIX] Ignorando troca automática de ativo:', aid);
      return;
    }
    const info = activeMap[aid];
    const name = info?.name || `Active #${aid}`;
    selectedAsset = name;

    // Update asset type for SDK asset-type tracking
    if (info?.assetType) {
      currentAssetType = info.assetType; // 'digital' | 'binary'
      console.log('[Claude IA] Asset type:', currentAssetType, 'for', name);
    }

    // If a Q5 session is running and NOT currently executing an entry,
    // stop it — entries must only happen for the asset that was active
    // when user clicked Start.
    // IMPORTANT: if q5Executing is true we are mid-entry (pin3 click +
    // wait + buy/sell click). Don't kill the session — the broker often
    // sends active-change events when a new position is opened.
    if (q5Running && !q5Executing && !q5ExecutingGrace) {
      q5Running = false;
      // Return to configured state and warn user
      setState('configured');
      const ticker = typeof $ === 'function' ? $('lab-ticker') : null;
      if (ticker) ticker.textContent = '⚠️ Sessão encerrada — ativo alterado';
    }

    // Update display labels
    ['anal-asset','sig-asset-name','sig-meta-asset'].forEach(id => {
      const el = typeof $ === 'function' ? $(id) : null;
      if (el) el.textContent = name;
    });

    // Reset trend state for new asset
    consecutiveUp = 0; consecutiveDown = 0; lastCandle = null;
    recomputeTrend(aid);

    // Render immediately — show cached candles or waiting state
    renderCandleHistory(aid);
    updateCandleBar({ close: 0, open: 0 }); // reset bar

    // Request fresh candles via WS
    setTimeout(() => {
      try { window.__cia_request_candles?.(aid, 10); } catch {}
    }, 200);

    checkAnalyzeReady();
  }

  // Candle state
  let lastCandle     = null;
  let candleTrend    = null;
  let consecutiveUp  = 0;
  let consecutiveDown= 0;

  function recomputeTrend(aid) {
    // Only update global state for the current active
    if (aid !== currentActiveId) return;
    const sorted = getCandlesSorted(aid);
    consecutiveUp = 0; consecutiveDown = 0;
    sorted.slice(-5).forEach(c => {
      if (c.close > c.open)      { consecutiveUp++;   consecutiveDown = 0; }
      else if (c.close < c.open) { consecutiveDown++; consecutiveUp   = 0; }
      else                       { consecutiveUp = 0; consecutiveDown = 0; }
    });
    lastCandle  = sorted.length ? sorted[sorted.length - 1] : null;
    candleTrend = consecutiveUp >= 2 ? 'up' : consecutiveDown >= 2 ? 'down' : 'neutral';
  }

  function onCandleUpdate(c) {
    const aid = c.active_id;
    if (aid !== currentActiveId) return;
    recomputeTrend(aid);
    updateCandleTicker(lastCandle || c);
    updateCandleBar(lastCandle || c);
    renderCandleHistory(aid);
    if (q5Running) q5OnCandle(c);
  }

  // ── Render last 5 candles ─────────────────────────────────────────
  function renderCandleHistory(aid) {
    const el = typeof $ === 'function' ? $('candle-history') : null;
    if (!el) return;
    const candles = getCandlesSorted(aid).slice(-5);

    if (!candles.length) {
      el.style.display = 'block';
      const info = activeMap[aid];
      const name = info?.name || (aid ? `Ativo #${aid}` : '');
      el.innerHTML = `
        <div style="display:flex;align-items:center;gap:7px;margin-bottom:5px">
          <span class="spin" style="width:6px;height:6px;border-width:1.2px;flex-shrink:0"></span>
          <div>
            ${name ? `<div style="font-family:var(--fh);font-size:12px;letter-spacing:1px;color:var(--tx)">${name}</div>` : ''}
            <div style="font-family:var(--fh);font-size:8px;letter-spacing:2px;color:var(--Gll)">M1 · MONITORANDO...</div>
          </div>
        </div>
        <div style="font-family:var(--fb);font-size:10px;font-weight:300;color:var(--mu)">
          Aguardando próxima vela de 1 minuto.
        </div>`;
      return;
    }
    el.style.display = 'block';

    const prec      = activeMap[aid]?.precision || 6;
    const assetName = activeMap[aid]?.name || `#${aid}`;
    const CHART_H   = 64; // px — chart area height

    // Price scale using all wicks for full range
    const allPrices = candles.flatMap(c => [c.min, c.max]);
    const minP = Math.min(...allPrices);
    const maxP = Math.max(...allPrices);
    // Add 10% padding so candles don't touch top/bottom
    const pad  = (maxP - minP) * 0.1 || 0.0001;
    const low  = minP - pad;
    const high = maxP + pad;
    const range = high - low;

    // Map price → pixel from top (0 = top = highest price)
    const px = v => Math.round(((high - v) / range) * CHART_H);

    // Always render in a fixed 5-slot grid (right-aligned)
    const SLOTS    = 5;
    const slotW    = 40;
    const slotGap  = 6;
    const bodyW    = 24;
    const startSlot = SLOTS - candles.length; // right-align

    const candlesSVG = candles.map((c, i) => {
      const bull    = c.close >= c.open;
      const col     = bull ? '#2ecc8a' : '#e05060';
      const isLast  = i === candles.length - 1;
      const opacity = isLast ? 1 : 0.6 + i * 0.1;
      const slot    = startSlot + i;
      const xOff    = slot * (slotW + slotGap);
      const cx      = xOff + slotW / 2;

      const wickTop = px(c.max);
      const wickBot = px(c.min);
      const wickH   = Math.max(1, wickBot - wickTop);

      const bodyTop = px(Math.max(c.open, c.close));
      const bodyBot = px(Math.min(c.open, c.close));
      const bodyH   = Math.max(3, bodyBot - bodyTop);

      return `<g opacity="${opacity}">
        <rect x="${cx - 1}" y="${wickTop}" width="2" height="${wickH}" fill="${col}"/>
        <rect x="${cx - bodyW/2}" y="${bodyTop}" width="${bodyW}" height="${bodyH}"
              fill="${col}" rx="1"${isLast ? ` style="filter:drop-shadow(0 0 5px ${col})"` : ''}/>
      </g>`;
    }).join('');

    const svgW        = SLOTS * (slotW + slotGap) - slotGap; // 5 * 46 - 6 = 224
    const displayPrec = prec > 5 ? 5 : prec;

    el.innerHTML = `
      <div class="ch-header">
        <div style="display:flex;align-items:center;gap:7px">
          <span class="spin" style="width:6px;height:6px;border-width:1.2px;flex-shrink:0"></span>
          <div>
            <div style="font-family:var(--fh);font-size:12px;letter-spacing:1px;color:var(--tx)">${assetName}</div>
            <div style="font-family:var(--fh);font-size:8px;letter-spacing:2px;color:var(--Gll);margin-top:1px">M1 · ÚLTIMAS ${candles.length}/5 VELAS</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="ch-streak">
            ${consecutiveUp   >= 2 ? `<span style="color:var(--gn)">${consecutiveUp}× ▲</span>` :
              consecutiveDown >= 2 ? `<span style="color:var(--rd)">${consecutiveDown}× ▼</span>` :
              '<span style="color:var(--mu)">neutro</span>'}
          </div>
          <button onclick="(function(aid){try{window.__cia_request_candles&&window.__cia_request_candles(${aid},10)}catch{}})(${aid})" style="background:var(--Gd);border:1px solid var(--G);border-radius:2px;color:var(--Gll);font-size:9px;padding:2px 6px;cursor:pointer;font-family:var(--fh);letter-spacing:.5px">↺</button>
        </div>
      </div>
      <svg width="100%" viewBox="0 0 ${svgW} ${CHART_H}"
           style="display:block;margin-bottom:6px"
           preserveAspectRatio="xMidYMid meet">
        ${candlesSVG}
      </svg>
      <div style="display:grid;grid-template-columns:repeat(${SLOTS},1fr);gap:4px">
        ${Array.from({length: SLOTS}, (_, i) => {
          const ci = i - startSlot;
          const c  = (ci >= 0 && ci < candles.length) ? candles[ci] : null;
          if (!c) return '<div></div>';
          const bull = c.close >= c.open;
          const col  = bull ? '#2ecc8a' : '#e05060';
          return '<div style="text-align:center;font-family:monospace;font-size:8px;color:' + col + ';overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + c.close.toFixed(displayPrec) + '</div>';
        }).join('')}
      </div>`;
  }

  function updateCandleTicker(c) {
    const el = typeof $ === 'function' ? $('lab-ticker') : null;
    if (!el) return;
    const dir   = c.close > c.open ? '▲' : c.close < c.open ? '▼' : '—';
    const color = c.close > c.open ? '#2ecc8a' : c.close < c.open ? '#e05060' : '#6aacb2';
    const diff  = (c.close - c.open).toFixed(5);
    el.innerHTML = `<span style="color:${color}">${dir}</span> Vela ${dir === '▲' ? 'ALTA' : dir === '▼' ? 'BAIXA' : 'DOJI'} &nbsp;|&nbsp; O:${c.open.toFixed(5)} C:${c.close.toFixed(5)} &nbsp;<span style="color:${color}">${diff > 0 ? '+' : ''}${diff}</span>`;
  }

  function updateCandleBar(c) {
    const el = typeof $ === 'function' ? $('candle-bar') : null;
    if (!el) return;
    el.style.display = 'flex';
    const dir   = c.close > c.open ? '▲' : c.close < c.open ? '▼' : '—';
    const color = c.close > c.open ? '#2ecc8a' : c.close < c.open ? '#e05060' : '#6aacb2';
    el.querySelector('.cb-price').textContent  = c.close.toFixed(5);
    el.querySelector('.cb-dir').textContent    = dir;
    el.querySelector('.cb-dir').style.color    = color;
    el.querySelector('.cb-streak').textContent =
      consecutiveUp >= 2   ? `${consecutiveUp}× ▲`  :
      consecutiveDown >= 2 ? `${consecutiveDown}× ▼` : 'neutro';
    el.querySelector('.cb-streak').style.color = color;
  }

  // ── Smart signal based on real candles ───────────────────────────
  function generateSmartSignal() {
    const aid     = currentActiveId;
    const history = aid ? getCandlesSorted(aid) : [];
    if (!lastCandle || history.length < 3) {
      return { isCall: Math.random() > 0.5, assert: (95 + Math.random() * 3).toFixed(1) };
    }
    const last3  = history.slice(-3);
    const bulls  = last3.filter(c => c.close > c.open).length;
    const bears  = last3.filter(c => c.close < c.open).length;
    const isCall = bulls >= 2 ? true : bears >= 2 ? false : Math.random() > 0.5;
    const base   = (bulls === 3 || bears === 3) ? 97 : (bulls === 2 || bears === 2) ? 96 : 95;
    const assert = (base + Math.random() * 1.5).toFixed(1);
    return { isCall, assert };
  }

  // ── Analysis steps ───────────────────────────────────────────────
  const STEPS = [
    { icon: '📊', label: 'Analisando Price Action' },
    { icon: '🎯', label: 'Verificando Zonas de Suporte' },
    { icon: '🧮', label: 'Calculando Probabilidades' },
    { icon: '🔄', label: 'Padrões de Reversão' },
    { icon: '⚡', label: 'Confluência de Indicadores' },
    { icon: '🚀', label: 'Gerando Sinal...' },
  ];

  // ── Shadow host ──────────────────────────────────────────────────
  const host = document.createElement('div');
  host.id = ROOT_ID;
  host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;pointer-events:none;';
  document.documentElement.appendChild(host);
  const shadow = host.attachShadow({ mode: 'open' });

  // ── Styles ───────────────────────────────────────────────────────
  const css = document.createElement('style');
  css.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap');
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    :host{all:initial}

    .panel{
      /* ── Navy blue fintech palette ── */
      --b0:    #05091a;
      --b1:    #0a1028;
      --b2:    #0e1535;
      --b3:    #131c42;
      --b4:    #182050;
      --br:    rgba(40,75,200,.18);
      --br2:   rgba(50,90,220,.28);
      --bl:    #1a4aff;   /* blue accent */
      --blm:   #2255ff;
      --bld:   #0a2acc;
      --bldim: rgba(26,74,255,.12);
      --gn:    #00d084;   /* bright green */
      --gnd:   #00a868;
      --rd:    #ff3b5c;   /* bright red */
      --rdd:   #cc2040;
      --tx:    #e8f0ff;
      --tx2:   #a0b4d8;
      --mu:    #4a6090;
      --mu2:   #2a3860;
      --ease:  cubic-bezier(0.16,1,0.3,1);
      --f:     'Outfit',system-ui,sans-serif;
      --r:     12px;      /* border-radius */

      pointer-events:all;position:fixed;width:340px;max-height:90vh;
      background:var(--b0);
      border:1px solid var(--br2);
      border-radius:16px;
      display:flex;flex-direction:column;font-family:var(--f);color:var(--tx);
      overflow:hidden;cursor:default;
      box-shadow:
        0 0 0 1px rgba(40,75,200,.1),
        0 32px 80px rgba(0,0,5,.9),
        0 0 60px rgba(26,74,255,.06),
        inset 0 1px 0 rgba(120,160,255,.06);
      transition:opacity .25s var(--ease),transform .25s var(--ease);
      user-select:none;
    }
    .panel.hidden{opacity:0;transform:scale(.94) translateY(10px);pointer-events:none}
    .panel.mini .p-body,.panel.mini .p-tabs{display:none}
    .panel.mini .p-hdr{border-radius:16px;border-bottom:none}

    /* ── Header ── */
    .p-hdr{
      position:relative;z-index:1;
      padding:9px 14px;
      background:#000;
      border-bottom:1px solid rgba(255,255,255,.06);
      border-radius:16px 16px 0 0;
      display:flex;align-items:center;justify-content:space-between;
      cursor:grab;flex-shrink:0;
    }
    .p-hdr.drag{cursor:grabbing}
    .panel.mini .p-hdr{border-radius:16px;border-bottom:none}

    .grip{display:flex;flex-wrap:wrap;gap:2.5px;width:12px;margin-right:9px;opacity:.2;flex-shrink:0}
    .grip span{display:block;width:3px;height:3px;border-radius:50%;background:var(--tx)}

    .brand{display:flex;align-items:center;gap:9px}
    .bico{
      width:30px;height:30px;
      background:var(--bldim);
      border:1px solid rgba(40,75,200,.4);
      border-radius:9px;
      display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;
      transition:all .3s var(--ease);
    }
    .bico:hover{background:rgba(26,74,255,.2);transform:scale(1.08)}
    .bname{font-size:15px;font-weight:700;color:var(--tx);line-height:1;letter-spacing:-.2px}
    .bname span{color:#6090ff}
    .bsub{font-size:9px;font-weight:400;color:var(--mu);letter-spacing:.8px;text-transform:uppercase;margin-top:1px;opacity:.7}

    .lbadge{
      display:flex;align-items:center;gap:6px;
      background:rgba(0,208,132,.1);
      border:1px solid rgba(0,208,132,.3);
      border-radius:20px;padding:5px 12px;
      font-size:11px;font-weight:700;color:var(--gn);letter-spacing:.8px;text-transform:uppercase;
    }
    .ldot{width:6px;height:6px;border-radius:50%;background:var(--gn);animation:blink 1.4s infinite;flex-shrink:0;box-shadow:0 0 5px var(--gn)}
    @keyframes blink{0%,100%{opacity:1}50%{opacity:.2}}

    .wc{display:flex;gap:4px;flex-shrink:0}
    .wb{
      width:28px;height:28px;border-radius:8px;border:1px solid transparent;
      cursor:pointer;display:flex;align-items:center;justify-content:center;
      font-size:11px;font-weight:700;transition:all .2s var(--ease);
    }
    .wb#wgear{background:var(--b3);color:var(--tx2);border-color:var(--br2)}
    .wb#wgear:hover{background:var(--b4);color:var(--tx);border-color:rgba(50,90,220,.4)}
    .wb.mn{background:var(--b3);color:var(--tx2);border-color:var(--br2)}
    .wb.mn:hover{background:var(--b4);color:var(--tx)}
    .wb.cl{background:rgba(255,59,92,.08);color:var(--rd);border-color:rgba(255,59,92,.25)}
    .wb.cl:hover{background:var(--rd);color:#fff;transform:scale(1.05)}

    /* ── Tabs ── */
    .p-tabs{
      position:relative;z-index:1;
      display:flex;border-bottom:1px solid var(--br);background:var(--b1);flex-shrink:0;
    }
    .pt{
      flex:1;padding:10px 0;background:none;border:none;border-bottom:2px solid transparent;
      color:var(--mu);font-family:var(--f);font-size:11px;font-weight:600;
      letter-spacing:.5px;text-transform:uppercase;cursor:pointer;
      transition:color .2s,border-color .2s;
    }
    .pt:hover{color:var(--tx2)}
    .pt.on{color:#6090ff;border-bottom-color:var(--bl)}

    /* ── Body ── */
    .p-body{flex:1;overflow-y:auto;overflow-x:hidden;position:relative;z-index:1}
    .p-body::-webkit-scrollbar{width:3px}
    .p-body::-webkit-scrollbar-thumb{background:rgba(40,75,200,.3);border-radius:3px}
    .pane{display:none;padding:12px}.pane.on{display:block}

    /* ── Auto toggle ── */
    .arow{
      display:flex;align-items:center;justify-content:space-between;
      background:var(--b2);border:1px solid var(--br2);border-radius:var(--r);
      padding:11px 14px;margin-bottom:12px;gap:10px;
      transition:border-color .2s;
    }
    .arow:hover{border-color:rgba(50,90,220,.5)}
    .at{font-size:12px;font-weight:700;color:var(--tx)}
    .as{font-size:10px;font-weight:400;color:var(--mu);margin-top:2px;line-height:1.4}

    .sw{position:relative;width:42px;height:24px;flex-shrink:0}
    .sw input{opacity:0;width:0;height:0}
    .swtk{
      position:absolute;inset:0;background:var(--b3);
      border:1px solid var(--br2);border-radius:12px;cursor:pointer;
      transition:all .25s var(--ease);
    }
    .sw input:checked+.swtk{background:var(--bl);border-color:var(--blm)}
    .swtk::after{
      content:'';position:absolute;width:16px;height:16px;background:#fff;
      border-radius:50%;top:3px;left:3px;transition:transform .25s var(--ease);
      box-shadow:0 1px 4px rgba(0,0,0,.4);
    }
    .sw input:checked+.swtk::after{transform:translateX(18px)}

    /* ── Banners ── */
    .ban{
      background:var(--b2);border:1px solid var(--br2);border-radius:var(--r);
      padding:11px 13px;display:flex;align-items:flex-start;gap:10px;margin-bottom:12px;
      animation:reveal .4s var(--ease) both;
    }
    @keyframes reveal{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
    .ban .bi{font-size:18px;flex-shrink:0;margin-top:1px}
    .ban .bt{font-size:12px;font-weight:700;color:var(--tx)}
    .ban .bs{font-size:10px;color:var(--mu);margin-top:2px;line-height:1.5}
    .ban.ok{border-color:rgba(0,208,132,.3);background:rgba(0,208,132,.06)}
    .ban.ok .bt{color:var(--gn)}
    .ban.ready{border-color:rgba(26,74,255,.3);background:rgba(26,74,255,.06)}
    .ban.ready .bt{color:#6090ff}

    /* ── Config card ── */
    .ccard{
      background:var(--b1);border:1px solid var(--br2);border-radius:var(--r);
      padding:20px 16px;text-align:center;margin-bottom:12px;
      position:relative;overflow:hidden;
      animation:reveal .4s .08s var(--ease) both;
      transition:border-color .2s,transform .2s;
    }
    .ccard:hover{border-color:rgba(50,90,220,.5);transform:translateY(-1px)}
    .ccard::before{
      content:'';position:absolute;width:140px;height:140px;
      background:radial-gradient(circle,rgba(26,74,255,.12),transparent 70%);
      border-radius:50%;top:-30px;right:-20px;filter:blur(30px);pointer-events:none;
    }
    .ccico{font-size:28px;margin-bottom:10px;display:block}
    .cctit{font-size:15px;font-weight:700;color:var(--tx);margin-bottom:6px}
    .ccdesc{font-size:11px;font-weight:400;color:var(--mu);line-height:1.6;margin-bottom:15px}

    /* ── Buttons ── */
    .btn{
      width:100%;padding:12px;border-radius:var(--r);
      border:1px solid rgba(50,90,220,.45);
      background:linear-gradient(135deg,#0e2060,#0a1840);
      color:#6090ff;font-family:var(--f);font-size:12px;font-weight:600;
      cursor:pointer;transition:all .25s var(--ease);
      display:flex;align-items:center;justify-content:center;gap:8px;
    }
    .btn:hover{background:linear-gradient(135deg,#142880,#0e2060);transform:translateY(-1px);border-color:var(--bl)}
    .btn[disabled]{opacity:.35;cursor:not-allowed;transform:none!important}

    /* "Iniciar Análise" button */
    .btn-analyze{
      width:100%;padding:14px 20px;
      border-radius:14px;border:none;
      background:linear-gradient(160deg,#1a4aff 0%,#0d2acc 100%);
      color:#fff;font-family:var(--f);font-size:15px;font-weight:700;
      cursor:pointer;transition:all .25s var(--ease);
      position:relative;letter-spacing:.3px;
      box-shadow:0 5px 20px rgba(26,74,255,.4),inset 0 1px 0 rgba(255,255,255,.12);
    }
    .btn-analyze:hover{
      background:linear-gradient(160deg,#2255ff 0%,#1535ee 100%);
      transform:translateY(-1px);
      box-shadow:0 8px 28px rgba(26,74,255,.5),inset 0 1px 0 rgba(255,255,255,.16);
    }
    .btn-analyze:active{transform:translateY(0)}
    .btn-analyze[disabled]{opacity:.35;cursor:not-allowed;transform:none!important;box-shadow:none}

    .btn-live{
      width:100%;padding:12px;border-radius:var(--r);border:1px solid rgba(0,208,132,.3);
      background:rgba(0,208,132,.07);color:var(--gn);
      font-family:var(--f);font-size:12px;font-weight:600;
      cursor:pointer;transition:all .25s var(--ease);
      display:flex;align-items:center;justify-content:center;gap:8px;
    }
    .btn-live:hover{background:rgba(0,208,132,.15);transform:translateY(-1px)}

    .btn-sm{
      width:100%;padding:8px;background:transparent;
      border:1px solid var(--br);border-radius:9px;
      color:var(--mu);font-family:var(--f);font-size:10px;
      cursor:pointer;transition:all .2s;margin-top:8px;
    }
    .btn-sm:hover{color:var(--rd);border-color:rgba(255,59,92,.35)}


    /* ── Analysis ── */
    .acard{
      background:var(--b1);border:1px solid var(--br2);border-radius:var(--r);
      padding:16px;animation:reveal .35s var(--ease) both;
    }
    .ahdr{text-align:center;margin-bottom:14px}
    .albl{font-size:9px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;color:var(--mu);margin-bottom:4px}
    .aasset{font-size:22px;font-weight:800;color:var(--tx);line-height:1}
    .astatus{
      display:inline-flex;align-items:center;gap:5px;
      background:rgba(26,74,255,.1);border:1px solid rgba(26,74,255,.3);
      border-radius:20px;padding:3px 11px;
      font-size:10px;font-weight:600;color:#6090ff;letter-spacing:.5px;margin-top:7px;
    }
    .spin{
      width:9px;height:9px;border:2px solid rgba(96,144,255,.3);border-top-color:#6090ff;
      border-radius:50%;animation:sp .7s linear infinite;flex-shrink:0;display:inline-block;
    }
    @keyframes sp{to{transform:rotate(360deg)}}

    .pwrap{margin-bottom:14px}
    .pmeta{display:flex;justify-content:space-between;font-size:10px;margin-bottom:5px}
    .plbl{color:var(--mu);font-weight:500}
    .ppct{color:#6090ff;font-weight:700}
    .ptrack{height:3px;background:var(--b3);border-radius:3px;overflow:hidden}
    .pbar{height:100%;background:linear-gradient(90deg,var(--bl),#6090ff);border-radius:3px;transition:width .5s var(--ease);width:0%}

    .slist{display:flex;flex-direction:column;gap:6px}
    .step{
      display:flex;align-items:center;gap:9px;padding:9px 11px;
      background:var(--b2);border:1px solid var(--br);border-radius:10px;
      transition:all .3s var(--ease);opacity:.3;
    }
    .step.active{opacity:1;border-color:rgba(26,74,255,.4);background:rgba(26,74,255,.07);transform:translateX(2px)}
    .step.done{opacity:1;border-color:rgba(0,208,132,.25);background:rgba(0,208,132,.05)}
    .step .sico{font-size:13px;flex-shrink:0}
    .step .slbl{font-size:11px;font-weight:500;flex:1}
    .step.active .slbl{color:#6090ff;font-weight:600}
    .step.done .slbl{color:var(--gn)}
    .step .sst{flex-shrink:0;font-size:13px}

    /* ── Signal ── */
    .sigcard{
      background:var(--b1);border:1px solid var(--br2);border-radius:var(--r);
      padding:16px;animation:reveal .4s var(--ease) both;
    }
    .sighdr{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:13px}
    .siglbl{font-size:9px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;color:var(--mu)}
    .sigasset{font-size:20px;font-weight:800;color:var(--tx);margin-top:2px;line-height:1}
    .btn-cls{
      background:var(--b3);border:1px solid var(--br2);border-radius:8px;
      color:var(--mu);padding:5px 11px;font-family:var(--f);font-size:10px;font-weight:500;
      cursor:pointer;flex-shrink:0;transition:all .2s;
    }
    .btn-cls:hover{color:var(--tx);border-color:rgba(50,90,220,.4)}

    .sigmain{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:11px}
    .sigdir{
      border-radius:var(--r);padding:18px 10px;text-align:center;
      display:flex;flex-direction:column;align-items:center;gap:5px;
      transition:transform .3s var(--ease);
    }
    .sigdir:hover{transform:scale(1.02)}
    .sigdir.call{background:rgba(0,208,132,.08);border:1px solid rgba(0,208,132,.3)}
    .sigdir.put{background:rgba(255,59,92,.08);border:1px solid rgba(255,59,92,.3)}
    .sigarrow{font-size:22px}
    .signame{font-size:28px;font-weight:800;letter-spacing:1px;line-height:1}
    .sigdir.call .signame{color:var(--gn)}.sigdir.put .signame{color:var(--rd)}

    .sigas{
      background:var(--b2);border:1px solid var(--br2);border-radius:var(--r);
      padding:18px 10px;text-align:center;
      display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;
    }
    .salbl{font-size:8px;font-weight:600;letter-spacing:1.5px;text-transform:uppercase;color:var(--mu)}
    .saval{font-size:28px;font-weight:800;color:#6090ff;line-height:1}
    .sabar{width:100%;height:2px;background:var(--b0);border-radius:2px;margin-top:7px;overflow:hidden}
    .safil{height:100%;background:linear-gradient(90deg,var(--bl),#6090ff);border-radius:2px;transition:width 1.2s var(--ease)}

    .sigmeta{display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px;margin-bottom:11px}
    .sm{background:var(--b2);border:1px solid var(--br);border-radius:10px;padding:8px;text-align:center}
    .sml{font-size:8px;font-weight:600;letter-spacing:.8px;text-transform:uppercase;color:var(--mu);margin-bottom:3px}
    .smv{font-size:11px;font-weight:700;color:var(--tx)}

    .btn-exec{
      width:100%;padding:14px;border:none;border-radius:var(--r);
      font-family:var(--f);font-size:13px;font-weight:700;
      letter-spacing:.3px;cursor:pointer;transition:all .3s var(--ease);
      position:relative;overflow:hidden;
    }
    .btn-exec.call{background:var(--gn);color:#050a14}
    .btn-exec.put{background:var(--rd);color:#fff}
    .btn-exec::after{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(255,255,255,.15),transparent);opacity:0;transition:opacity .2s}
    .btn-exec:hover::after{opacity:1}
    .btn-exec:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,.3)}

    .autonote{
      display:flex;align-items:flex-start;gap:8px;border-radius:10px;
      padding:10px 12px;font-size:10px;font-weight:500;margin-top:10px;line-height:1.5;
    }

    /* ── Live URL ── */
    .lhero{
      background:var(--b1);border:1px solid rgba(0,208,132,.25);border-radius:var(--r);
      padding:22px;text-align:center;margin-bottom:12px;
      position:relative;overflow:hidden;animation:reveal .4s var(--ease) both;
    }
    .lhero::before{
      content:'';position:absolute;width:150px;height:150px;
      background:radial-gradient(circle,rgba(0,208,132,.1),transparent 70%);
      border-radius:50%;top:-30px;left:50%;transform:translateX(-50%);
      filter:blur(35px);pointer-events:none;
    }
    .lico{font-size:32px;margin-bottom:10px;display:block;position:relative;z-index:1}
    .ltit{font-size:16px;font-weight:700;color:var(--tx);margin-bottom:6px;position:relative;z-index:1}
    .ldesc{font-size:11px;color:var(--mu);line-height:1.6;margin-bottom:15px;position:relative;z-index:1}
    .lurlinp{
      width:100%;background:var(--b2);border:1px solid var(--br2);border-radius:10px;
      color:var(--tx);font-family:var(--f);font-size:12px;padding:9px 11px;
      outline:none;transition:border-color .2s;margin-bottom:7px;position:relative;z-index:1;
    }
    .lurlinp:focus{border-color:rgba(50,90,220,.6)}
    .lurlinp::placeholder{color:var(--mu2)}
    .lurlhint{font-size:10px;color:var(--mu);margin-bottom:13px;position:relative;z-index:1}

    /* ── Settings overlay ── */
    .settings-overlay{
      position:absolute;inset:0;background:var(--b0);z-index:10;
      display:flex;flex-direction:column;
      opacity:0;visibility:hidden;pointer-events:none;
      transition:opacity .2s ease, visibility .2s ease;
    }
    .settings-overlay.open{
      opacity:1;visibility:visible;pointer-events:all;
    }
    .settings-hdr{
      display:flex;align-items:center;gap:10px;
      padding:14px 16px;
      background:linear-gradient(135deg,#0a1028,#0e1535);
      border-bottom:1px solid rgba(40,75,200,.25);flex-shrink:0;
    }
    .settings-hdr-back{
      width:28px;height:28px;border-radius:8px;border:1px solid var(--br);
      background:var(--b2);color:var(--tx2);cursor:pointer;
      display:flex;align-items:center;justify-content:center;font-size:14px;
      transition:all .2s;flex-shrink:0;
    }
    .settings-hdr-back:hover{background:var(--b3);color:var(--tx)}
    .settings-hdr-title{font-size:13px;font-weight:700;color:var(--tx);letter-spacing:.2px;flex:1}
    .settings-body{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:12px}
    .settings-body::-webkit-scrollbar{width:3px}
    .settings-body::-webkit-scrollbar-thumb{background:rgba(40,75,200,.3);border-radius:3px}

    /* Setting cards */
    .cfg-card{
      background:var(--b1);border:1px solid var(--br);border-radius:14px;
      padding:14px;display:flex;flex-direction:column;gap:12px;
    }
    .cfg-row{display:flex;align-items:center;justify-content:space-between;gap:10px}
    .cfg-label{font-size:11px;font-weight:500;color:var(--tx2)}
    .cfg-sublabel{font-size:9px;color:var(--mu);margin-top:1px}
    .cfg-inp{
      background:var(--b2);border:1px solid var(--br);border-radius:8px;
      color:var(--tx);font-size:12px;font-weight:600;padding:6px 10px;
      text-align:right;width:80px;outline:none;transition:border-color .2s;
    }
    .cfg-inp:focus{border-color:rgba(26,74,255,.6)}
    .cfg-select{
      background:var(--b2);border:1px solid var(--br);border-radius:8px;
      color:var(--tx);font-size:11px;font-weight:600;padding:6px 10px;
      outline:none;cursor:pointer;transition:border-color .2s;
    }
    .cfg-select:focus{border-color:rgba(26,74,255,.6)}
    .cfg-card-label{font-size:9px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:var(--mu)}
    .cfg-prefix{font-size:12px;font-weight:700;color:var(--tx2)}
    .cfg-sel{
      background:var(--b2);border:1px solid var(--br);border-radius:8px;
      color:var(--tx);font-size:11px;font-weight:600;padding:8px 10px;
      outline:none;cursor:pointer;transition:border-color .2s;width:100%;
    }
    .cfg-sel:focus{border-color:rgba(26,74,255,.6)}

    /* ── Strategy picker (custom dropdown) ── */
    .strategy-field-label{
      font-family:var(--fb);font-size:9px;font-weight:700;letter-spacing:1.2px;
      text-transform:uppercase;color:var(--mu);margin-bottom:8px;
    }
    .strategy-sel-visually-hidden{
      position:absolute!important;width:1px!important;height:1px!important;
      padding:0!important;margin:-1px!important;overflow:hidden!important;
      clip:rect(0,0,0,0)!important;border:0!important;white-space:nowrap!important;
    }
    .strategy-dd-wrap{position:relative;margin-bottom:12px}
    .strategy-dd{position:relative;width:100%}
    .strategy-dd-btn{
      width:100%;display:flex;align-items:center;justify-content:space-between;gap:12px;
      padding:12px 14px;border-radius:12px;cursor:pointer;font-family:var(--f);
      font-size:13px;font-weight:600;color:var(--tx);text-align:left;
      border:1px solid rgba(50,90,220,.38);
      background:linear-gradient(165deg, var(--b3) 0%, var(--b1) 100%);
      box-shadow:
        0 1px 0 rgba(255,255,255,.04) inset,
        0 8px 24px rgba(0,0,0,.35);
      transition:border-color .2s var(--ease), box-shadow .2s var(--ease), transform .15s var(--ease);
    }
    .strategy-dd-btn:hover{
      border-color:rgba(96,144,255,.55);
      box-shadow:0 1px 0 rgba(255,255,255,.06) inset, 0 10px 28px rgba(26,74,255,.12);
    }
    .strategy-dd-btn:focus{outline:none;border-color:#6090ff;box-shadow:0 0 0 2px rgba(96,144,255,.2)}
    .strategy-dd-btn.open{
      border-color:rgba(96,144,255,.65);
      box-shadow:0 0 0 1px rgba(96,144,255,.25), 0 12px 32px rgba(0,0,0,.4);
    }
    .strategy-dd-label{flex:1;min-width:0;letter-spacing:.02em}
    .strategy-dd-chevron{
      flex-shrink:0;display:flex;color:#6090ff;opacity:.9;
      transition:transform .22s var(--ease);
    }
    .strategy-dd-btn.open .strategy-dd-chevron{transform:rotate(180deg)}
    .strategy-dd-menu{
      position:absolute;left:0;right:0;top:calc(100% + 8px);z-index:30;
      margin:0;padding:6px;list-style:none;border-radius:14px;
      background:linear-gradient(180deg, #0e1535 0%, #080d22 100%);
      border:1px solid rgba(50,90,220,.45);
      box-shadow:
        0 0 0 1px rgba(26,74,255,.08),
        0 20px 50px rgba(0,0,0,.65),
        0 0 40px rgba(26,74,255,.06);
      max-height:min(280px, 45vh);overflow-y:auto;
      scrollbar-width:thin;
      scrollbar-color:rgba(40,75,200,.4) transparent;
    }
    .strategy-dd-menu::-webkit-scrollbar{width:4px}
    .strategy-dd-menu::-webkit-scrollbar-thumb{background:rgba(40,75,200,.45);border-radius:4px}
    .strategy-dd-menu[hidden]{display:none!important}
    .strategy-dd-item{
      padding:11px 14px;margin:2px 0;border-radius:10px;cursor:pointer;
      font-size:13px;font-weight:500;color:var(--tx2);
      transition:background .15s var(--ease), color .15s var(--ease), transform .1s var(--ease);
    }
    .strategy-dd-item:hover{
      background:rgba(26,74,255,.14);color:var(--tx);
    }
    .strategy-dd-item.is-active{
      background:linear-gradient(135deg, rgba(26,74,255,.28), rgba(26,74,255,.1));
      color:#7ab0ff;font-weight:700;border:1px solid rgba(96,144,255,.35);
      box-shadow:0 0 16px rgba(26,74,255,.12);
    }

    /* Balance display */
    .bal-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
    .bal-cell{
      background:var(--b2);border:1px solid var(--br);border-radius:10px;
      padding:10px;display:flex;flex-direction:column;gap:3px;
    }
    .bal-type{font-size:8px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--mu)}
    .bal-amount{font-size:13px;font-weight:700;color:var(--tx)}
    .bal-cell.demo .bal-amount{color:var(--gn)}

    /* Status badge */
    .status-badge{
      display:inline-flex;align-items:center;gap:6px;
      padding:7px 12px;border-radius:10px;font-size:10px;font-weight:700;letter-spacing:.3px;
    }
    .status-badge.ok{background:rgba(0,208,132,.1);border:1px solid rgba(0,208,132,.3);color:var(--gn)}
    .status-badge.err{background:rgba(255,59,92,.08);border:1px solid rgba(255,59,92,.3);color:var(--rd)}
    .status-badge.wait{background:var(--b2);border:1px solid var(--br);color:var(--mu)}
    .status-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;animation:blink 1.4s infinite}
    .status-badge.ok .status-dot{background:var(--gn)}
    .status-badge.err .status-dot{background:var(--rd);animation:none}
    .status-badge.wait .status-dot{background:var(--mu);animation:none}

    .settings-section{margin-bottom:0}
    .settings-section-title{font-size:9px;font-weight:700;letter-spacing:1.5px;
      text-transform:uppercase;color:var(--mu);margin-bottom:8px}

    /* ── Trade config ── */
    .cfg-section{margin-bottom:14px}
    .cfg-section-label{font-size:9px;font-weight:700;letter-spacing:1.5px;
      text-transform:uppercase;color:var(--mu);margin-bottom:7px}

    .asset-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:5px}
    .asset-pill{
      padding:8px 6px;text-align:center;background:var(--b2);
      border:1px solid var(--br);border-radius:9px;cursor:pointer;
      font-size:10px;font-weight:600;color:var(--mu);transition:all .2s;
    }
    .asset-pill:hover{border-color:rgba(50,90,220,.45);color:var(--tx2)}
    .asset-pill.selected{background:rgba(26,74,255,.12);border-color:rgba(50,90,220,.5);color:#6090ff}

    .time-row{display:flex;gap:7px}
    .time-pill{
      flex:1;padding:10px 8px;text-align:center;background:var(--b2);
      border:1px solid var(--br);border-radius:var(--r);cursor:pointer;
      font-size:10px;font-weight:600;color:var(--mu);transition:all .2s;
    }
    .time-pill:hover{border-color:rgba(50,90,220,.45);color:var(--tx2)}
    .time-pill.selected{background:rgba(26,74,255,.12);border-color:rgba(50,90,220,.5);color:#6090ff}
    .time-pill .tp-val{font-size:16px;font-weight:800;display:block}
    .time-pill.disabled{opacity:.3;cursor:not-allowed;pointer-events:none}

    .cfg-note{
      font-size:10px;color:var(--mu);margin-top:7px;padding:7px 10px;
      background:rgba(26,74,255,.06);border:1px solid rgba(26,74,255,.18);
      border-radius:9px;line-height:1.5;
    }
    .cfg-note strong{color:#6090ff;font-weight:600}

    /* ── Session ── */
    .session-card{
      background:var(--b1);border:1px solid var(--br2);border-radius:var(--r);
      padding:14px;animation:reveal .3s var(--ease) both;
    }
    .session-hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
    .session-title{font-size:12px;font-weight:700;color:var(--tx);letter-spacing:.3px}
    .session-timer{font-size:20px;font-weight:800;color:#6090ff;letter-spacing:1px}

    .entry-slots{display:flex;flex-direction:column;gap:6px;margin-bottom:12px}
    .entry-slot{
      display:flex;align-items:center;gap:9px;padding:9px 11px;
      background:var(--b2);border:1px solid var(--br);border-radius:10px;
      transition:all .3s var(--ease);
    }
    .entry-slot.pending{opacity:.4}
    .entry-slot.running{opacity:1;border-color:rgba(26,74,255,.4);background:rgba(26,74,255,.07)}
    .entry-slot.done-call{opacity:1;border-color:rgba(0,208,132,.3);background:rgba(0,208,132,.05)}
    .entry-slot.done-put{opacity:1;border-color:rgba(255,59,92,.25);background:rgba(255,59,92,.04)}
    .es-num{font-size:11px;color:var(--mu);flex-shrink:0;width:18px}
    .es-label{font-size:10px;font-weight:500;flex:1;color:var(--tx)}
    .es-badge{font-size:9px;font-weight:700;letter-spacing:.5px;padding:2px 8px;border-radius:10px;flex-shrink:0}
    .entry-slot.done-call .es-badge{background:rgba(0,208,132,.15);color:var(--gn)}
    .entry-slot.done-put  .es-badge{background:rgba(255,59,92,.12);color:var(--rd)}
    .entry-slot.running   .es-badge{background:rgba(26,74,255,.12);color:#6090ff}
    .session-footer{font-size:10px;color:var(--mu);text-align:center}

    /* ── Placar da sessão ── */
    .score-board{
      display:flex;align-items:center;justify-content:center;
      background:var(--b1);border:1px solid var(--br);border-radius:12px;
      padding:12px 8px;margin-bottom:10px;gap:0;
    }
    .score-cell{display:flex;flex-direction:column;align-items:center;flex:1;gap:3px}
    .score-val{font-size:26px;font-weight:800;line-height:1;letter-spacing:-1px;transition:all .3s var(--ease)}
    .score-lbl{font-size:8px;font-weight:700;letter-spacing:2px;text-transform:uppercase;opacity:.5}
    .score-cell.win  .score-val{color:var(--gn);text-shadow:0 0 14px rgba(0,208,132,.4)}
    .score-cell.loss .score-val{color:var(--rd);text-shadow:0 0 14px rgba(255,59,92,.35)}
    .score-cell.neutral .score-val{color:var(--tx2)}
    .score-divider{width:1px;height:36px;background:var(--br);flex-shrink:0;margin:0 8px}

    @keyframes score-pop{0%{transform:scale(1)}40%{transform:scale(1.35)}100%{transform:scale(1)}}
    .score-pop{animation:score-pop .35s var(--ease) both}

    /* ── Live analysis ticker ── */
    .live-analysis-box{
      background:var(--b2);border:1px solid var(--br2);border-radius:var(--r);
      padding:11px 13px;
    }
    .lab-header{display:flex;align-items:center;gap:7px;margin-bottom:5px}
    .lab-title{font-size:9px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#6090ff}
    .lab-ticker{font-size:11px;font-weight:500;color:var(--tx);transition:opacity .2s}

    /* ── Candle history card ── */
    .candle-history{
      display:none;background:var(--b2);border:1px solid var(--br2);
      border-radius:var(--r);padding:11px;margin-bottom:10px;
    }
    .ch-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
    .ch-title{display:flex;align-items:center;gap:5px;font-size:9px;font-weight:700;
      letter-spacing:1px;text-transform:uppercase;color:#6090ff}
    .ch-streak{font-size:11px;font-weight:700}
    .ch-chart{position:relative;height:60px;display:flex;gap:4px;align-items:stretch;margin-bottom:4px}
    .ch-candle{flex:1;position:relative;min-width:0}
    .ch-wick{position:absolute;width:1px;left:50%;transform:translateX(-50%)}
    .ch-body{position:absolute;width:70%;left:15%;border-radius:2px;min-height:2px}
    .ch-lbl{position:absolute;bottom:-14px;left:50%;transform:translateX(-50%);font-size:8px;font-weight:700}
    .ch-candle.ch-latest .ch-body{box-shadow:0 0 6px currentColor;opacity:.95}
    .ch-prices{display:flex;gap:4px}
    .ch-price{flex:1;text-align:center;font-family:'Courier New',monospace;
      font-size:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .candle-bar{
      display:none;align-items:center;gap:10px;
      background:var(--b2);border:1px solid var(--br2);border-radius:var(--r);
      padding:8px 12px;margin-bottom:10px;}
    .cb-dir{font-size:18px;flex-shrink:0}
    .cb-info{flex:1;min-width:0}
    .cb-label{font-size:8px;font-weight:600;letter-spacing:1px;text-transform:uppercase;color:var(--mu);margin-bottom:2px}
    .cb-price{font-size:15px;font-weight:700;color:var(--tx);letter-spacing:.5px}
    .cb-streak{font-size:10px;font-weight:600;padding:2px 8px;border-radius:10px;background:var(--b3);flex-shrink:0}

    /* ── Candle M1 progress bar (like the screenshot) ── */
    .candle-progress-wrap{
      display:flex;align-items:center;justify-content:space-between;
      margin-top:8px;gap:8px;
    }
    .candle-progress-lbl{font-size:10px;font-weight:500;color:var(--mu)}
    .candle-progress-pct{font-size:10px;font-weight:600;color:var(--tx2)}
    .candle-progress-track{flex:1;height:3px;background:var(--b3);border-radius:3px;overflow:hidden}
    .candle-progress-bar{height:100%;background:linear-gradient(90deg,var(--gn),#00ffaa);border-radius:3px;transition:width .5s}

    /* ── Terms of Use overlay ── */
    .terms-overlay{
      position:absolute;inset:0;z-index:50;
      background:var(--b0);
      display:flex;flex-direction:column;align-items:center;justify-content:center;
      padding:18px;border-radius:16px;
    }
    .terms-body{display:flex;flex-direction:column;align-items:center;width:100%;max-height:100%}
    .terms-logo{
      width:52px;height:52px;border-radius:14px;
      background:rgba(26,74,255,.12);border:1px solid rgba(50,90,220,.35);
      display:flex;align-items:center;justify-content:center;
      margin-bottom:12px;flex-shrink:0;
    }
    .terms-title{font-size:18px;font-weight:800;color:var(--tx);margin-bottom:4px;text-align:center}
    .terms-subtitle{font-size:11px;color:var(--mu);margin-bottom:14px;text-align:center}
    .terms-scroll{
      width:100%;overflow-y:auto;
      background:var(--b2);border:1px solid var(--br2);border-radius:12px;
      padding:14px;margin-bottom:14px;max-height:300px;
    }
    .terms-scroll::-webkit-scrollbar{width:3px}
    .terms-scroll::-webkit-scrollbar-thumb{background:rgba(40,75,200,.3);border-radius:3px}
    .terms-section-title{font-size:11px;font-weight:700;color:#6090ff;margin:12px 0 5px}
    .terms-section-title:first-child{margin-top:0}
    .terms-text{font-size:11px;color:var(--tx2);line-height:1.6;margin-bottom:4px}
    .terms-accept{
      width:100%;padding:14px;border-radius:12px;border:none;
      background:linear-gradient(160deg,#1a4aff,#0d2acc);
      color:#fff;font-size:14px;font-weight:700;cursor:pointer;letter-spacing:.3px;
      box-shadow:0 5px 20px rgba(26,74,255,.4);transition:all .2s;flex-shrink:0;
    }
    .terms-accept:hover{background:linear-gradient(160deg,#2255ff,#1535ee);transform:translateY(-1px)}
    .terms-footer{font-size:10px;color:var(--mu);margin-top:10px;text-align:center;line-height:1.5}
  `;
  shadow.appendChild(css);


  // ── HTML ─────────────────────────────────────────────────────────
  const ui = document.createElement('div');
  ui.innerHTML = `
    <div class="panel hidden" id="panel">

      <!-- Header -->
      <div class="p-hdr" id="dh">
        <div style="display:flex;align-items:center;gap:0">
          <div class="grip"><span></span><span></span><span></span><span></span><span></span><span></span></div>
          <img src="${chrome.runtime.getURL('img/LOGO.png')}"
               alt="Logo"
               style="height:34px;width:auto;object-fit:contain;display:block"/>
        </div>
        <div style="display:flex;align-items:center;gap:7px">

          <div class="wc">
            <button class="wb" id="wgear" title="Configurações">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
              </svg>
            </button>
            <button class="wb mn" id="wmin">—</button>
            <button class="wb cl" id="wcls">✕</button>
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <div class="p-tabs" style="display:none">
        <button class="pt on" data-t="op">Operações</button>
      </div>

      <!-- Content -->
      <div class="p-body">

        <!-- ══ Operações ══ -->
        <div class="pane on" id="pane-op">

          <!-- state: welcome screen -->
          <div id="st-welcome" style="display:block">
            <div style="display:flex;flex-direction:column;align-items:center;gap:0;padding:0">

              <!-- Banner boas-vindas inline -->
              <div style="
                width:100%;border-radius:12px;margin-bottom:16px;
                background:linear-gradient(160deg,#0a0f1e 0%,#0d1530 60%,#0a0f1e 100%);
                display:flex;flex-direction:column;align-items:center;
                padding:28px 16px 22px;box-sizing:border-box;
                position:relative;overflow:hidden;
                border:1.5px solid rgba(255,140,0,.25);
                box-shadow:0 0 40px rgba(255,120,0,.08),inset 0 1px 0 rgba(255,200,80,.07);
              ">
                <!-- brilho de fundo -->
                <div style="position:absolute;top:-40px;left:50%;transform:translateX(-50%);
                  width:260px;height:120px;border-radius:50%;
                  background:radial-gradient(ellipse,rgba(255,160,0,.18) 0%,transparent 70%);
                  pointer-events:none"></div>

                <!-- BEM-VINDO AO -->
                <div style="
                  font-family:'Outfit',system-ui,sans-serif;
                  font-size:15px;font-weight:800;letter-spacing:4px;
                  text-transform:uppercase;
                  color:#ffd84d;
                  text-shadow:0 0 12px rgba(255,200,0,.7),0 0 30px rgba(255,160,0,.4);
                  -webkit-text-stroke:1px rgba(255,140,0,.6);
                  margin-bottom:6px;
                ">BEM-VINDO AO</div>

                <!-- velas decorativas -->
                <svg width="80" height="44" viewBox="0 0 80 44" fill="none" style="margin-bottom:4px;filter:drop-shadow(0 0 8px rgba(255,160,0,.5))">
                  <!-- vela esquerda (baixa) -->
                  <rect x="8" y="22" width="10" height="16" rx="2" fill="#ff8c00" opacity=".9"/>
                  <line x1="13" y1="22" x2="13" y2="16" stroke="#ffd84d" stroke-width="1.5"/>
                  <line x1="13" y1="38" x2="13" y2="42" stroke="#ffd84d" stroke-width="1.5"/>
                  <!-- vela central (alta) -->
                  <rect x="34" y="8" width="12" height="28" rx="2" fill="#ffd84d"/>
                  <line x1="40" y1="8" x2="40" y2="2" stroke="#ffd84d" stroke-width="1.5"/>
                  <line x1="40" y1="36" x2="40" y2="42" stroke="#ffd84d" stroke-width="1.5"/>
                  <!-- vela direita (média) -->
                  <rect x="62" y="16" width="10" height="20" rx="2" fill="#ff6a00" opacity=".9"/>
                  <line x1="67" y1="16" x2="67" y2="10" stroke="#ffd84d" stroke-width="1.5"/>
                  <line x1="67" y1="36" x2="67" y2="42" stroke="#ffd84d" stroke-width="1.5"/>
                </svg>

                <!-- ATOSPRO -->
                <div style="
                  font-family:'Outfit',system-ui,sans-serif;
                  font-size:40px;font-weight:900;letter-spacing:4px;
                  text-transform:uppercase;line-height:1;
                  color:#ffd84d;
                  -webkit-text-stroke:2px #ff6a00;
                  text-shadow:
                    0 0 8px #ffaa00,
                    0 0 20px rgba(255,140,0,.8),
                    0 0 40px rgba(255,80,0,.5),
                    2px 2px 0px #cc5500;
                  position:relative;
                ">ATOSPRO</div>

                <!-- borda de brilho embaixo do título -->
                <div style="width:80%;height:2px;margin-top:10px;
                  background:linear-gradient(90deg,transparent,#ff8c00,#ffd84d,#ff8c00,transparent);
                  border-radius:2px;opacity:.8"></div>

                <!-- moedas e botões CALL/PUT -->
                <div style="display:flex;align-items:center;gap:12px;margin-top:14px">
                  <div style="
                    padding:7px 22px;border-radius:6px;font-weight:800;font-size:14px;
                    letter-spacing:1.5px;color:#fff;font-family:'Outfit',system-ui,sans-serif;
                    background:linear-gradient(180deg,#2ecc40,#1a8a28);
                    border:1.5px solid rgba(255,255,100,.3);
                    box-shadow:0 2px 10px rgba(46,204,64,.3);
                  ">CALL</div>

                  <!-- moedas -->
                  <svg width="36" height="28" viewBox="0 0 36 28" fill="none" style="filter:drop-shadow(0 2px 6px rgba(255,180,0,.5))">
                    <ellipse cx="12" cy="20" rx="10" ry="6" fill="#cc8800"/>
                    <ellipse cx="12" cy="17" rx="10" ry="6" fill="#ffcc00"/>
                    <ellipse cx="12" cy="17" rx="7" ry="4" fill="#ffe566" opacity=".6"/>
                    <ellipse cx="24" cy="14" rx="10" ry="6" fill="#cc8800"/>
                    <ellipse cx="24" cy="11" rx="10" ry="6" fill="#ffcc00"/>
                    <ellipse cx="24" cy="11" rx="7" ry="4" fill="#ffe566" opacity=".6"/>
                  </svg>

                  <div style="
                    padding:7px 22px;border-radius:6px;font-weight:800;font-size:14px;
                    letter-spacing:1.5px;color:#fff;font-family:'Outfit',system-ui,sans-serif;
                    background:linear-gradient(180deg,#e74c3c,#9b2318);
                    border:1.5px solid rgba(255,255,100,.3);
                    box-shadow:0 2px 10px rgba(231,76,60,.3);
                  ">PUT</div>
                </div>
              </div>
              <!-- fim banner -->

              <button class="btn-analyze" id="btn-start-welcome"
                      style="width:100%;margin-top:4px">
                Começar
              </button>
            </div>
          </div>

          <!-- state: trade config (after pins set) -->
          <div id="st-cfg" style="display:none">

            <div class="arow" style="margin-bottom:12px">
              <div>
                <div class="at" style="display:flex;align-items:center;gap:8px">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;color:#6090ff">
                    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
                  </svg>
                  Modo Automático
                </div>
                <div class="as">Executa entradas automaticamente ao sinal.</div>
              </div>
              <label class="sw"><input type="checkbox" id="auto-chk"><span class="swtk"></span></label>
            </div>

            <div class="arow" style="margin-bottom:12px">
              <div>
                <div class="at" style="display:flex;align-items:center;gap:8px">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;color:#6090ff">
                    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>
                  </svg>
                  Martingale
                </div>
                <div class="as">Dobra o valor na perda, reseta no win.</div>
              </div>
              <label class="sw"><input type="checkbox" id="martingale-chk"><span class="swtk"></span></label>
            </div>

            <div class="strategy-dd-wrap">
              <div class="strategy-field-label">Estratégia da sessão</div>
              <select id="strategy-sel" class="strategy-sel-visually-hidden" tabindex="-1" aria-hidden="true">
                <option value="claude_pro">Claude Pro</option>
                <option value="q5">Estratégia 5w</option>
                <option value="alt">Alternante</option>
                <option value="sniper">Sniper</option>
                <option value="hard">Hard</option>
              </select>
              <div class="strategy-dd" id="strategy-dd">
                <button type="button" class="strategy-dd-btn" id="strategy-dd-btn" aria-expanded="false" aria-haspopup="listbox">
                  <span class="strategy-dd-label" id="strategy-dd-label">Claude Pro</span>
                  <span class="strategy-dd-chevron" aria-hidden="true">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                  </span>
                </button>
                <ul class="strategy-dd-menu" id="strategy-dd-menu" role="listbox" hidden>
                  <li role="option" class="strategy-dd-item" data-value="claude_pro" tabindex="-1">Claude Pro</li>
                  <li role="option" class="strategy-dd-item" data-value="q5" tabindex="-1">Estratégia 5w</li>
                  <li role="option" class="strategy-dd-item" data-value="alt" tabindex="-1">Alternante</li>
                  <li role="option" class="strategy-dd-item" data-value="sniper" tabindex="-1">Sniper</li>
                  <li role="option" class="strategy-dd-item" data-value="hard" tabindex="-1">Hard</li>
                </ul>
              </div>
            </div>

            <div class="ban ok" style="margin-bottom:10px;align-items:center">
              <div style="width:34px;height:34px;border-radius:10px;background:rgba(0,208,132,.15);border:1px solid rgba(0,208,132,.35);display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00d084" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 2a10 10 0 1 0 10 10"/><path d="m9 12 2 2 4-4"/><path d="M22 2 12 12"/>
                </svg>
              </div>
              <div><div class="bt">IA Calibrada</div>
                <div class="bs">Configure o ativo e o tempo para iniciar.</div></div>
            </div>

            <!-- Live candle monitor -->
            <div class="candle-bar" id="candle-bar">
              <span class="cb-dir">—</span>
              <div class="cb-info">
                <div class="cb-label">Última Vela</div>
                <div class="cb-price">—</div>
              </div>
              <span class="cb-streak">—</span>
            </div>

            <!-- Candle history (last 5) -->
            <div class="candle-history" id="candle-history"></div>

            <!-- Entry value -->
            <div style="display:flex;align-items:center;justify-content:space-between;background:var(--b1);border:1px solid var(--br);border-radius:10px;padding:10px 13px;margin-bottom:8px">
              <span style="font-family:var(--fb);font-size:10px;font-weight:700;color:var(--tx2)">Valor de Entrada</span>
              <div style="display:flex;align-items:center;gap:5px">
                <span style="font-size:10px;font-weight:700;color:var(--mu)">R$</span>
                <input id="main-amount-inp" type="number" min="1" step="1" value="5"
                  style="width:56px;background:var(--b2);border:1px solid var(--br);border-radius:7px;color:var(--tx);font-size:13px;font-weight:700;padding:4px 8px;text-align:right;outline:none"/>
              </div>
            </div>

            <!-- Account (fixed: Real only) -->
            <div style="margin-bottom:10px">
              <div style="font-family:var(--fb);font-size:9px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--mu);margin-bottom:6px">Conta Real</div>
              <div style="display:flex;align-items:center;justify-content:space-between;background:rgba(26,74,255,.08);border:1px solid rgba(50,90,220,.45);border-radius:11px;padding:11px 14px">
                <div style="display:flex;flex-direction:column;gap:2px">
                  <span style="font-size:8px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#6090ff">Real</span>
                  <span id="bal-real-amt" style="font-size:14px;font-weight:700;color:var(--tx)">—</span>
                </div>
                <div id="bal-lock-msg" style="font-size:9px;font-weight:700;color:var(--rd);display:none">Mín. R$ 60</div>
              </div>
            </div>

            <button class="btn-analyze" id="btn-analyze" disabled>Iniciar Análise</button>
          </div>

          <!-- state: analyzing (single entry) -->
          <div id="st-anal" style="display:none">
            <div class="acard">
              <div class="ahdr">
                <div class="albl">Analisando Mercado</div>
                <div class="aasset" id="anal-asset">EUR/USD</div>
                <div class="astatus"><span class="spin"></span>&nbsp;PROCESSANDO</div>
              </div>
              <div class="pwrap">
                <div class="pmeta"><span class="plbl">Progresso</span><span class="ppct" id="ppct">0%</span></div>
                <div class="ptrack"><div class="pbar" id="pbar"></div></div>
              </div>
              <div class="slist" id="slist"></div>
            </div>
          </div>

          <!-- state: signal (single entry result) -->
          <div id="st-sig" style="display:none">
            <div class="sigcard">
              <div class="sighdr">
                <div><div class="siglbl">Sinal Gerado</div><div class="sigasset" id="sig-asset-name">EUR/USD</div></div>
                <button class="btn-cls" id="btn-cls-sig">Fechar</button>
              </div>
              <div class="sigmain">
                <div class="sigdir" id="sig-dir">
                  <span class="sigarrow" id="sig-arrow">▲</span>
                  <span class="signame"  id="sig-name">CALL</span>
                </div>
                <div class="sigas">
                  <div class="salbl">Assertividade</div>
                  <div class="saval" id="sa-val">0%</div>
                  <div class="sabar"><div class="safil" id="sa-fil" style="width:0%"></div></div>
                </div>
              </div>
              <div class="sigmeta">
                <div class="sm"><div class="sml">Entrada</div><div class="smv" id="sig-entry-time">1 min</div></div>
                <div class="sm"><div class="sml">Ativo</div><div class="smv" id="sig-meta-asset">EUR/USD</div></div>
                <div class="sm"><div class="sml">Sessão</div><div class="smv" id="sig-session">1/3</div></div>
              </div>
              <button class="btn-exec" id="btn-exec">Confirmar Entrada</button>
              <div class="autonote" id="autonote" style="display:none"></div>
            </div>
            <button class="btn-sm" id="btn-new" style="margin-top:9px">Encerrar Sessão</button>
          </div>

          <!-- state: session running -->
          <div id="st-session" style="display:none">
            <div class="session-card">
              <div class="session-hdr">
                <div class="session-title">ANALISANDO</div>
                <div style="display:flex;align-items:center;gap:5px">
                  <span class="ldot" style="background:var(--Gll)"></span>
                  <span style="font-family:var(--fh);font-size:9px;letter-spacing:1px;color:var(--Gll)">AO VIVO</span>
                </div>
              </div>

              <!-- Placar da sessão -->
              <div class="score-board" id="score-board">
                <div class="score-cell win">
                  <div class="score-val" id="score-win">0</div>
                  <div class="score-lbl">WIN</div>
                </div>
                <div class="score-divider"></div>
                <div class="score-cell loss">
                  <div class="score-val" id="score-loss">0</div>
                  <div class="score-lbl">LOSS</div>
                </div>
                <div class="score-divider"></div>
                <div class="score-cell neutral">
                  <div class="score-val" id="score-total">0</div>
                  <div class="score-lbl">TOTAL</div>
                </div>
              </div>

              <div class="entry-slots" id="entry-slots"></div>
              <div class="session-footer" id="session-footer">Monitorando quadrantes...</div>
            </div>
            <button class="btn-sm" id="btn-stop-session" style="margin-top:10px;border-color:var(--rd2);color:var(--rd)">⏹ Parar Análise</button>
          </div>

        </div><!-- /pane-op -->

        <!-- Live pane hidden -->
        <div class="pane" id="pane-live" style="display:none">
          <input class="lurlinp" id="lurl" type="url" placeholder="https://..." style="display:none"/>
          <button class="btn-live" id="btn-live" style="display:none"></button>
        </div>

      </div><!-- /p-body -->

      <!-- ══ Settings Overlay ══ -->
      <div class="settings-overlay" id="settings-overlay">
        <div class="settings-hdr">
          <button class="settings-hdr-back" id="settings-close">‹</button>
          <span class="settings-hdr-title">Configurações</span>
        </div>
        <div class="settings-body">

          <!-- Status card -->
          <div class="cfg-card">
            <div class="cfg-card-label">Status</div>
            <div id="sdk-status" class="status-badge wait"><span class="status-dot"></span>Aguardando...</div>
          </div>

          <!-- Saldo card -->
          <div class="cfg-card" id="sdk-bal-row" style="display:none">
            <div class="cfg-card-label">Saldo</div>
            <div class="bal-grid">
              <div class="bal-cell demo">
                <span class="bal-type">Demo</span>
                <span id="sdk-demo-val" class="bal-amount">—</span>
              </div>
              <div class="bal-cell">
                <span class="bal-type">Real</span>
                <span id="sdk-real-val" class="bal-amount">—</span>
              </div>
            </div>
          </div>

          <!-- Entrada card -->
          <div class="cfg-card">
            <div class="cfg-card-label">Valor por Entrada</div>
            <div class="cfg-row">
              <span class="cfg-prefix">R$</span>
              <input id="sdk-amount-inp" type="number" min="1" step="1" value="5" class="cfg-inp"/>
            </div>
          </div>

          <!-- Conta card -->
          <div class="cfg-card">
            <div class="cfg-card-label">Conta</div>
            <select id="sdk-bal-sel" class="cfg-sel">
              <option value="real">Real</option>
            </select>
          </div>

        </div>
      </div>


    </div><!-- /panel -->
  `;
  shadow.appendChild(ui);

  // ── Refs ─────────────────────────────────────────────────────────
  const $  = id => shadow.getElementById(id);
  const panel = $('panel'), dh = $('dh');
  let appState = 'configured';
  let currentAssetType      = 'digital';
  let lockedAssetId = null;
  let autoMode  = false;

  // ── Position / drag ───────────────────────────────────────────────
  async function loadPos() {
    const r = await store.get(['cia_pos']);
    const p = r.cia_pos || { x: window.innerWidth - 356, y: 50 };
    applyPos(p.x, p.y);
  }
  function applyPos(x, y) {
    // Usa dimensão real se visível, senão usa fallback fixo (painel pode estar hidden)
    const pw = (panel.offsetWidth  > 10 ? panel.offsetWidth  : 340);
    const ph = (panel.offsetHeight > 10 ? panel.offsetHeight : 560);
    x = Math.max(8, Math.min(x, window.innerWidth  - pw - 8));
    y = Math.max(8, Math.min(y, window.innerHeight - ph - 8));
    // Garante que nunca vai pra fora da tela
    x = Math.max(8, x);
    y = Math.max(8, y);
    Object.assign(panel.style, { left: x+'px', top: y+'px', right: 'auto', bottom: 'auto' });
  }
  let drag=false,ox=0,oy=0;
  dh.addEventListener('mousedown', e => {
    if ($('settings-overlay')?.classList.contains('open')) return;
    if (e.target.closest('.wc')) return;
    if (e.target.closest('button,input,select,a')) return;
    drag=true; const r=panel.getBoundingClientRect();
    ox=e.clientX-r.left; oy=e.clientY-r.top;
    dh.classList.add('drag'); panel.style.transition='none'; e.preventDefault();
  });
  document.addEventListener('mousemove', e => { if(drag) applyPos(e.clientX-ox,e.clientY-oy); });
  document.addEventListener('mouseup', () => {
    if(!drag)return; drag=false; dh.classList.remove('drag'); panel.style.transition='';
    const r=panel.getBoundingClientRect(); store.set({cia_pos:{x:r.left,y:r.top}});
  });
  dh.addEventListener('touchstart', e => {
    // Não arrasta se a overlay de configurações estiver aberta
    if ($('settings-overlay')?.classList.contains('open')) return;
    if (e.target.closest('.wc')) return;
    // Só arrasta se tocar diretamente no header ou grip, não em botões/inputs
    if (e.target.closest('button,input,select,a')) return;
    const t=e.touches[0]; drag=true; const r=panel.getBoundingClientRect();
    ox=t.clientX-r.left; oy=t.clientY-r.top; panel.style.transition='none';
  },{passive:true});
  document.addEventListener('touchmove', e => {
    if(!drag)return; const t=e.touches[0]; applyPos(t.clientX-ox,t.clientY-oy);
  },{passive:true});
  document.addEventListener('touchend', () => {
    if(!drag)return; drag=false; panel.style.transition='';
    const r=panel.getBoundingClientRect(); store.set({cia_pos:{x:r.left,y:r.top}});
  });

  $('wmin').addEventListener('click', e => { e.stopPropagation(); panel.classList.toggle('mini'); });
  $('wcls').addEventListener('click', e => { e.stopPropagation(); panel.classList.add('hidden'); });

  // ── Tabs ──────────────────────────────────────────────────────────
  shadow.querySelectorAll('.pt').forEach(t => {
    t.addEventListener('click', () => {
      shadow.querySelectorAll('.pt').forEach(x => x.classList.remove('on'));
      shadow.querySelectorAll('.pane').forEach(x => x.classList.remove('on'));
      t.classList.add('on'); $('pane-'+t.dataset.t).classList.add('on');
    });
  });

  // ── Trade config state ─────────────────────────────────────────────
  let selectedAsset    = null;
  let selectedEntryMin = null; // 1 or 5
  let sessionTimers    = [];
  let sessionInterval  = null;
  let sessionStartTime = null;

  // ── State machine ─────────────────────────────────────────────────
  const states = ['st-welcome','st-cfg','st-anal','st-sig','st-session'];
  function setState(s) {
    appState = s;
    states.forEach(id => $(id) && ($(id).style.display = 'none'));
    const map = {
      'welcome':'st-welcome',  'configured':'st-cfg',   'analyzing':'st-anal',
      'signal':'st-sig',       'session':'st-session',
    };
    if (map[s]) $(map[s]).style.display = 'block';
    if (s === 'configured') renderCfgDisplay();
  }

  function renderCfgDisplay() {
    // Show candle history if we have an active
    if (currentActiveId) renderCandleHistory(currentActiveId);
    else {
      const ch = $('candle-history');
      if (ch) {
        ch.style.display = 'block';
        ch.innerHTML = `<div class="ch-header"><div class="ch-title"><span class="spin" style="width:6px;height:6px;border-width:1.2px;flex-shrink:0"></span>&nbsp;MONITORANDO VELAS...</div></div><div style="font-family:var(--fb);font-size:10px;font-weight:300;color:var(--mu);padding:4px 0">Aguardando dados do WebSocket.</div>`;
      }
    }
    checkAnalyzeReady();
  }

  function checkAnalyzeReady() {
    const btn = $('btn-analyze');
    if (!btn) return;
    const hasEnv = envFatalIssues.length === 0;
    const hasBalance = realBalance >= 0;
    const ready = hasEnv && autoMode && hasBalance;
    if (ready) {
      btn.removeAttribute('disabled');
      btn.title = '';
    } else {
      btn.setAttribute('disabled', '');
      if (!hasEnv)
        btn.title = envFatalIssues[0]?.detail || 'Ambiente incompatível detectado';
      else if (!sdkReady)
        btn.title = 'Aguardando conexão SDK...';
      else if (!hasBalance)
        btn.title = `Saldo insuficiente (atual: R$ ${realBalance.toFixed(2)})`;
      else if (!autoMode)
        btn.title = 'Ative o Modo Automático para iniciar';
    }
  }

  // ── Asset + time selectors ────────────────────────────────────────
  function initTradeConfig() {
    // Asset is auto-detected from WebSocket — no manual selection needed

    // Entry time pills
    shadow.querySelectorAll('[data-entry]').forEach(p => {
      p.addEventListener('click', () => {
        shadow.querySelectorAll('[data-entry]').forEach(x => x.classList.remove('selected'));
        p.classList.add('selected');
        selectedEntryMin = parseInt(p.dataset.entry);
        store.set({ cia_entry_min: selectedEntryMin });
        checkAnalyzeReady();
      });
    });
  }


  // ══════════════════════════════════════════════════════════════════
  // ══════════════════════════════════════════════════════════════════
  // ── Q5 STRATEGY ENGINE ───────────────────────────────────────────
  // Quadrants = clock-aligned 5-min blocks: 10:00-10:05, 10:05-10:10...
  // Enter on candle 4 (opposite direction) if candles 1+2+3 same color
  // Recovery on candle 5 (same direction) shown if entered on 4
  // ══════════════════════════════════════════════════════════════════

  function quadrantOf(fromTs)    { return Math.floor(fromTs / 300); }
  function posInQuadrant(fromTs) { return Math.floor((fromTs % 300) / 60); } // 0-4
  function quadrantStart(fromTs) { return Math.floor(fromTs / 300) * 300; }
  function q5Label(fromTs) {
    const d = new Date(fromTs * 1000);
    return `${String(d.getHours()).padStart(2,'0')}:${String(Math.floor(d.getMinutes()/5)*5).padStart(2,'0')}`;
  }

  let q5Running      = false;
  let q5EntriesDone  = 0;
  let sessionWins    = 0;
  let sessionLosses  = 0;

  /** @type {'q5'|'alt'|'sniper'|'claude_pro'|'hard'} */
  let sessionStrategy  = 'claude_pro';
  let hardTimerId      = null;
  let hardEnteredAt    = null;
  let hardEntryIsCall  = null;

  function updateScore(isWin) {
    if (isWin) sessionWins++; else sessionLosses++;
    const wEl = $('score-win'),  lEl = $('score-loss'), tEl = $('score-total');
    if (!wEl) return;
    wEl.textContent = sessionWins;
    lEl.textContent = sessionLosses;
    tEl.textContent = sessionWins + sessionLosses;
    const target = isWin ? wEl : lEl;
    target.classList.remove('score-pop');
    void target.offsetWidth; // reflow para reiniciar animação
    target.classList.add('score-pop');
  }
  let q5EnteredQuad  = null;   // quadrant where Q5 entered on candle 4
  let q5EntryIsCall  = null;   // direction of Q5 entry
  let q5ProcessedKey = null;
  let q5Executing    = false;

  // ── Alternation strategy state ──────────────────────────────────
  let altEnteredAt   = null;   // timestamp (from) of the candle ALT entered on
  let altEntryIsCall = null;   // direction of ALT entry

  // ── Last-2 strategy state ─────────────────────────────────────
  let last2EnteredQ  = null;   // quadrant where LAST2 entered (for result check)
  let last2EntryCall = null;   // direction of LAST2 entry
  let quadrantUsed   = false;  // true if any strategy already entered this quadrant

  // Called by onCandleUpdate for every live M1 candle
  // IMPORTANT: only acts on truly NEW candles (deduplicated by from timestamp)
  const q5SeenFrom = new Set(); // set of `from` timestamps already processed

  async function q5OnCandle(candle) {
    if (!q5Running) return;

    // Only process each unique candle ONCE (ignore partial live updates)
    const fromKey = `${candle.active_id}:${candle.from}`;
    if (q5SeenFrom.has(fromKey)) return;
    q5SeenFrom.add(fromKey);
    // Keep set small
    if (q5SeenFrom.size > 100) {
      const old = [...q5SeenFrom].slice(0, 50);
      old.forEach(k => q5SeenFrom.delete(k));
    }

    const pos   = posInQuadrant(candle.from);
    const q     = quadrantOf(candle.from);
    const aid   = candle.active_id;
    const qS    = quadrantStart(candle.from);
    const label = q5Label(candle.from);

    // When a new quadrant starts, reset recovery state
    if (q !== q5EnteredQuad) {
      // new quadrant — clear recovery only if it's truly a new quadrant
    }

    const sorted = getCandlesSorted(aid);
    const T      = candle.from; // open time of current candle

    // ══════════════════════════════════════════════════════════════
    // FASE 1 — VERIFICAÇÃO DE RESULTADOS (tem prioridade sobre tudo)
    // ══════════════════════════════════════════════════════════════

    // Q5: resultado na vela 4 (pos=3), verificado quando vela 5 abre (pos=4)
    if (pos === 4 && q5EnteredQuad === q) {
      const c4 = sorted.find(c => c.from === qS + 180);
      if (!c4) { q5SeenFrom.delete(fromKey); return; }
      const isWin    = q5EntryIsCall ? (c4.close >= c4.open) : (c4.close < c4.open);
      const savedCall = q5EntryIsCall;
      q5EnteredQuad  = null;
      q5EntryIsCall  = null;
      updateSessionTicker(`${isWin?'✅ WIN':'❌ LOSS'} — Q5 ${savedCall?'▲ CALL':'▼ PUT'}`);
      addResultRow(q, savedCall, label, isWin, 'Q5');
      updateSessionTicker('🔄 Pronto — analisando próximo padrão...');
      return;
    }

    // ALT: resultado quando o candle de entrada fechou (T > altEnteredAt)
    if (altEnteredAt !== null && T > altEnteredAt) {
      const entryC = sorted.find(c => c.from === altEnteredAt);
      if (!entryC) { q5SeenFrom.delete(fromKey); return; }
      const isWin    = altEntryIsCall ? (entryC.close >= entryC.open) : (entryC.close < entryC.open);
      const savedCall = altEntryIsCall;
      const savedAt  = altEnteredAt;
      altEnteredAt   = null;
      altEntryIsCall = null;
      updateSessionTicker(`${isWin?'✅ WIN':'❌ LOSS'} — ALT ${savedCall?'▲ CALL':'▼ PUT'}`);
      addResultRow(quadrantOf(savedAt), savedCall, q5Label(savedAt), isWin, 'ALT');
      updateSessionTicker('🔄 Pronto — analisando próximo padrão...');
      return;
    }

    // LAST2: resultado na vela 2 (pos=1), verificado quando vela 2 abre
    if (pos === 1 && last2EnteredQ === q) {
      const c0 = sorted.find(c => c.from === qS);
      if (!c0) { q5SeenFrom.delete(fromKey); return; }
      const isWin    = last2EntryCall ? (c0.close >= c0.open) : (c0.close < c0.open);
      const savedCall = last2EntryCall;
      last2EnteredQ  = null;
      last2EntryCall = null;
      updateSessionTicker(`${isWin?'✅ WIN':'❌ LOSS'} — LAST2 ${savedCall?'▲ CALL':'▼ PUT'}`);
      addResultRow(q, savedCall, label, isWin, 'LAST2');
      updateSessionTicker('🔄 Pronto — analisando próximo padrão...');
      return;
    }

    // HARD: resultado quando a vela de entrada fechou (igual lógica ALT)
    if (sessionStrategy === 'hard' && hardEnteredAt !== null && T > hardEnteredAt) {
      const entryC = sorted.find(c => c.from === hardEnteredAt);
      if (!entryC) { q5SeenFrom.delete(fromKey); return; }
      const isWin     = hardEntryIsCall ? (entryC.close >= entryC.open) : (entryC.close < entryC.open);
      const savedCall = hardEntryIsCall;
      const savedFrom = hardEnteredAt;
      hardEnteredAt   = null;
      hardEntryIsCall = null;
      updateSessionTicker(`${isWin?'✅ WIN':'❌ LOSS'} — HARD ${savedCall?'▲ CALL':'▼ PUT'}`);
      addResultRow(quadrantOf(savedFrom), savedCall, q5Label(savedFrom), isWin, 'HARD');
      updateSessionTicker('🔄 Pronto — aguardando próxima janela aleatória...');
      // Só agenda nova entrada depois da operação anterior fechar.
      scheduleHardEntry();
      return;
    }

    // ══════════════════════════════════════════════════════════════
    // FASE 2 — RESET NO INÍCIO DE NOVO QUADRANTE
    // ══════════════════════════════════════════════════════════════
    let prevWasUsed = false;
    if (pos === 0) {
      prevWasUsed  = quadrantUsed;
      quadrantUsed = false;
    }

    // ══════════════════════════════════════════════════════════════
    // FASE 3 — DETECÇÃO DE PADRÕES
    // ══════════════════════════════════════════════════════════════

    if (sessionStrategy === 'hard') {
      return;
    }

    const runQ5     = sessionStrategy === 'q5' || sessionStrategy === 'claude_pro';
    const runAlt    = sessionStrategy === 'alt' || sessionStrategy === 'claude_pro';
    const runSniper = sessionStrategy === 'sniper' || sessionStrategy === 'claude_pro';

    // ── Prioridade 1 — Q5: 3 velas iguais (verifica no pos=3) ────
    if (pos === 3 && runQ5 && !quadrantUsed && !q5Executing) {
      const c1 = sorted.find(c => c.from === qS);
      const c2 = sorted.find(c => c.from === qS + 60);
      const c3 = sorted.find(c => c.from === qS + 120);
      if (!c1 || !c2 || !c3) {
        updateSessionTicker(`Q${label} · Oportunidade Encontrada — aguardando histórico...`);
        q5SeenFrom.delete(fromKey);
        return;
      }
      const b1 = c1.close > c1.open;
      const b2 = c2.close > c2.open;
      const b3 = c3.close > c3.open;
      if (b1 === b2 && b2 === b3) {
        const isCall  = !b1;
        q5EnteredQuad = q;
        q5EntryIsCall = isCall;
        quadrantUsed  = true;
        q5Executing   = true;
        updateSessionTicker(`Q${label} · 🎯 Q5: 3× ${b1?'▲':'▼'} → ${isCall?'▲ CALL':'▼ PUT'} — Oportunidade Encontrada`);
        await q5ExecuteEntry(isCall, `Q${label} · Oportunidade Encontrada`, `Q5: 3× ${b1?'▲':'▼'}`);
        q5Executing = false;
        return;
      }
    }

    // ── Prioridade 2 — ALT: janela deslizante de 4 velas fechadas ─
    // Verifica em QUALQUER posição do gráfico — não fica restrito ao quadrante
    if (runAlt && !quadrantUsed && !altEnteredAt && !q5Executing) {
      const cA = sorted.find(c => c.from === T - 240);
      const cB = sorted.find(c => c.from === T - 180);
      const cC = sorted.find(c => c.from === T - 120);
      const cD = sorted.find(c => c.from === T - 60);
      if (cA && cB && cC && cD) {
        const bA = cA.close > cA.open;
        const bB = cB.close > cB.open;
        const bC = cC.close > cC.open;
        const bD = cD.close > cD.open;
        // Alternância perfeita: cada vela oposta à anterior
        if ((bA !== bB) && (bB !== bC) && (bC !== bD)) {
          const isCall   = !bD; // continua alternância (oposta à última)
          altEnteredAt   = T;   // registra timestamp do candle de entrada
          altEntryIsCall = isCall;
          quadrantUsed   = true;
          q5Executing    = true;
          updateSessionTicker(`Q${label} · 🔀 ALT: ${bA?'▲':'▼'}${bB?'▲':'▼'}${bC?'▲':'▼'}${bD?'▲':'▼'} → ${isCall?'▲ CALL':'▼ PUT'}`);
          await q5ExecuteEntry(isCall, `Q${label} · ALT`, `ALT: alternância livre`);
          q5Executing = false;
          return;
        }
      }
    }

    // ── Prioridade 3 — LAST2 (Sniper): verificação no início do novo quadrante
    // Checa as velas 4 e 5 do quadrante ANTERIOR (ambas já fechadas)
    if (pos === 0 && runSniper && !quadrantUsed && !prevWasUsed && !q5Executing) {
      const prevQS = qS - 300;
      const c4prev = sorted.find(c => c.from === prevQS + 180);
      const c5prev = sorted.find(c => c.from === prevQS + 240);
      if (c4prev && c5prev) {
        const b4p = c4prev.close > c4prev.open;
        const b5p = c5prev.close > c5prev.open;
        if (b4p === b5p) {
          const isCall   = !b5p;
          last2EnteredQ  = q;
          last2EntryCall = isCall;
          quadrantUsed   = true;
          q5Executing    = true;
          updateSessionTicker(`Q${label} · 🔚 LAST2: velas ${b5p?'▲▲':'▼▼'} → ${isCall?'▲ CALL':'▼ PUT'} vela 1`);
          await q5ExecuteEntry(isCall, `Q${label} · Vela 1`, `LAST2: 2 iguais no fim`);
          q5Executing = false;
          return;
        }
      }
    }

    // Ticker informativo (nenhuma entrada neste tick)
    if (pos === 0) {
      updateSessionTicker(`Q${label} · Vela 1/5 — analisando padrão...`);
    } else if (pos < 5) {
      updateSessionTicker(`Q${label} · Vela ${pos+1}/5 — analisando padrão...`);
    }
  }

  // Win notification row
  // ── Push resultado real para membros.html ─────────────────────────────────
  function pushTradeToDashboard(isCall, isWin, amount) {
    const assetName = activeMap[currentActiveId]?.name || 'Desconhecido';
    const payout    = 0.87; // aproximação; payout real depende do ativo
    const profit    = isWin ? +(amount * payout).toFixed(2) : -amount;
    const now       = new Date();
    const timeStr   = now.toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
    chrome.runtime.sendMessage({
      __cia_push__: true,
      type: 'TRADE_RESULT',
      data: {
        asset:     assetName,
        direction: isCall ? 'CALL' : 'PUT',
        result:    isWin ? 'WIN' : 'LOSS',
        amount,
        profit,
        time:      timeStr,
      },
    });
  }

  // ── Martingale: dobra na perda, volta ao base no win ─────────────
  function applyMartingale(isWin) {
    if (!martingaleEnabled) return; // martingale desligado
    if (isWin) {
      // Win: reseta para valor original
      if (martingaleActive) {
        martingaleActive = false;
        const base = martingaleBase;
        lastTradeAmount = base;
        martingaleSuppressSync = true;
        store.set({ cia_sdk_amount: base });
        const a1 = $('sdk-amount-inp'), a2 = $('main-amount-inp');
        if (a1) a1.value = base;
        if (a2) a2.value = base;
        martingaleSuppressSync = false;
        updateSessionTicker('🔄 Martingale resetado — volta para R$ ' + base);
      }
    } else {
      // Loss: dobra o valor para a próxima entrada
      const nextAmount = lastTradeAmount * 2;
      martingaleActive = true;
      lastTradeAmount = nextAmount;
      martingaleSuppressSync = true;
      store.set({ cia_sdk_amount: nextAmount });
      const a1 = $('sdk-amount-inp'), a2 = $('main-amount-inp');
      if (a1) a1.value = nextAmount;
      if (a2) a2.value = nextAmount;
      martingaleSuppressSync = false;
      updateSessionTicker('📈 Martingale: próxima entrada R$ ' + nextAmount);
    }
  }

  function addResultRow(q, isCall, label, isWin, strategy = 'Q5') {
    updateScore(isWin);
    pushTradeToDashboard(isCall, isWin, lastTradeAmount); // envia para membros.html
    applyMartingale(isWin); // martingale: dobra na perda, reseta no win
    const slots = $('entry-slots');
    if (!slots) return;
    const row = document.createElement('div');
    row.className = 'entry-slot';
    row.style.cssText = isWin
      ? 'border-color:rgba(46,204,138,.4);background:rgba(46,204,138,.07)'
      : 'border-color:rgba(224,80,96,.4);background:rgba(224,80,96,.06)';
    const stratBadge = strategy === 'HARD'
      ? '<span style="font-size:9px;background:rgba(160,160,170,.15);color:#b8c0d8;padding:1px 5px;border-radius:4px;margin-right:4px">HARD</span>'
      : strategy === 'ALT'
      ? '<span style="font-size:9px;background:rgba(100,60,255,.25);color:#a080ff;padding:1px 5px;border-radius:4px;margin-right:4px">ALT</span>'
      : strategy === 'LAST2'
      ? '<span style="font-size:9px;background:rgba(255,140,0,.2);color:#ffa040;padding:1px 5px;border-radius:4px;margin-right:4px">SNIPER</span>'
      : '<span style="font-size:9px;background:rgba(26,74,255,.25);color:#6090ff;padding:1px 5px;border-radius:4px;margin-right:4px">Q5</span>';
    const vela = strategy === 'ALT' ? 'Oportunidade Encontrada' : strategy === 'LAST2' ? 'Oportunidade Encontrada' : 'Oportunidade Encontrada';
    if (isWin) {
      row.innerHTML = `
        <span class="es-num">✅</span>
        <span class="es-label">${stratBadge}Q${label} · ${vela} — ${isCall?'▲ CALL':'▼ PUT'}</span>
        <span class="es-badge" style="color:#2ecc8a">WIN</span>`;
    } else {
      row.innerHTML = `
        <span class="es-num" style="color:#e05060;font-size:16px;font-weight:900">✕</span>
        <span class="es-badge" style="color:#e05060;font-size:13px;font-weight:800;letter-spacing:1px;margin-left:auto">LOSS</span>`;
    }
    slots.appendChild(row);
    row.scrollIntoView({ behavior:'smooth', block:'nearest' });
  }

  // Recovery suggestion row (manual mode only)
  function addRecoveryRow(q, isCall, label) {
    const slots = $('entry-slots');
    if (!slots) return;
    const row = document.createElement('div');
    row.className = 'entry-slot pending';
    row.style.cssText = 'border-color:rgba(106,172,178,.35);background:rgba(53,79,82,.08)';
    row.innerHTML = `
      <span class="es-num">💡</span>
      <span class="es-label">Q${label} · Vela 5 — recovery ${isCall?'▲ CALL':'▼ PUT'}</span>
      <span class="es-badge" style="color:var(--Gll)">confirme manualmente</span>`;
    slots.appendChild(row);
    row.scrollIntoView({ behavior:'smooth', block:'nearest' });
  }

  function showOpportunityToast(isCall, strategy) {
    const existing = document.getElementById('__cia_opp_toast__');
    if (existing) existing.remove();

    const dir   = isCall ? '▲ CALL' : '▼ PUT';
    const color = isCall ? '#00d084' : '#ff3b5c';
    const strat = strategy || 'Q5';

    const el = document.createElement('div');
    el.id = '__cia_opp_toast__';
    el.style.cssText = [
      'position:fixed','top:50%','left:50%',
      'transform:translate(-50%,-50%) scale(.85)',
      'z-index:2147483646',
      'background:rgba(5,9,26,.96)',
      `border:1.5px solid ${color}`,
      'border-radius:20px',
      'padding:28px 40px',
      'text-align:center',
      'pointer-events:none',
      `box-shadow:0 0 60px ${color}33, 0 24px 80px rgba(0,0,0,.9)`,
      'transition:opacity .25s ease, transform .25s ease',
      'opacity:0',
      "font-family:'Outfit',system-ui,sans-serif",
    ].join(';');

    el.innerHTML = `
      <div style="font-size:10px;font-weight:700;letter-spacing:3px;text-transform:uppercase;color:#4a6090;margin-bottom:10px">
        ${strat}
      </div>
      <div style="font-size:13px;font-weight:600;letter-spacing:2px;text-transform:uppercase;color:#a0b4d8;margin-bottom:14px">
        Oportunidade Identificada
      </div>
      <div style="font-size:36px;font-weight:800;color:${color};letter-spacing:2px;line-height:1;margin-bottom:8px;text-shadow:0 0 20px ${color}88">
        ${dir}
      </div>
      <div style="font-size:10px;color:#4a6090;letter-spacing:1px;margin-top:6px">Executando entrada...</div>
    `;

    document.documentElement.appendChild(el);

    // Animate in
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        el.style.opacity    = '1';
        el.style.transform  = 'translate(-50%,-50%) scale(1)';
      });
    });

    // Animate out after 2.5s
    setTimeout(() => {
      el.style.opacity   = '0';
      el.style.transform = 'translate(-50%,-50%) scale(.92)';
      setTimeout(() => el.remove(), 280);
    }, 2500);
  }

  async function q5ExecuteEntry(isCall, label, reason) {
    const idx    = q5EntriesDone++;
    const assert = generateSmartSignal().assert;
    // Protege sessão contra reset por ativo-change durante e logo após a entrada
    q5ExecutingGrace = true;
    const graceTimer = setTimeout(() => { q5ExecutingGrace = false; }, 5000);

    // Detecta estratégia pelo reason para exibir no toast
    const stratName = (reason === 'HARD' || reason?.startsWith('HARD')) ? 'HARD'
                    : reason?.startsWith('ALT') ? 'ALT'
                    : reason?.startsWith('LAST2') ? 'LAST2'
                    : 'Q5';
    showOpportunityToast(isCall, stratName);

    const slots = $('entry-slots');
    if (slots) {
      const row = document.createElement('div');
      row.className = `entry-slot ${isCall?'done-call':'done-put'}`;
      row.id = `es-${idx}`;
      row.innerHTML = `
        <span class="es-num">${idx+1}</span>
        <span class="es-label">${label}</span>
        <span class="es-badge">${autoMode?'...':isCall?'CALL':'PUT'}</span>`;
      slots.appendChild(row);
      row.scrollIntoView({ behavior:'smooth', block:'nearest' });
    }

    updateSessionTicker(`🎯 ${isCall?'▲ CALL':'▼ PUT'} — ${reason} · ${assert}%`);

    if (autoMode) {
      // try-finally guarantees q5Executing is ALWAYS reset even on exception
      let result = { ok: false, error: 'erro desconhecido' };
      try {
        result = await executeEntry(isCall, false, true); // skipSessionCheck=true
      } catch (err) {
        result = { ok: false, error: err?.message || String(err) };
      }
      if (sessionStrategy === 'hard' && !result.ok) {
        hardEnteredAt   = null;
        hardEntryIsCall = null;
      }
      const bdg = $(`esb-${idx}`);
      if (bdg) bdg.textContent = isCall ? 'CALL' : 'PUT';
      const lbl = document.querySelector(`#es-${idx} .es-label`);
      if (lbl) lbl.textContent = `${label} — ${assert}%`;
      updateSessionTicker(result.ok
        ? `✅ ${isCall?'▲ CALL':'▼ PUT'} executado (${assert}%)`
        : `⚠️ Falha: ${result.error}`);
    } else {
      updateSessionTicker(`📋 Confirme: ${isCall?'▲ CALL':'▼ PUT'} — ${reason}`);
    }
  }

  function updateSessionTicker(msg) {
    const el = $('lab-ticker');
    if (!el) return;
    el.style.opacity = '0';
    setTimeout(() => { if(el) { el.textContent = msg; el.style.opacity='1'; }}, 150);
  }

  function q5Finish(reason) {
    if (!q5Running) return;
    clearHardTimer();
    hardEnteredAt   = null;
    hardEntryIsCall = null;
    q5Running        = false;
    q5Executing      = false;
    q5ExecutingGrace = false;
    altEnteredAt   = null;
    altEntryIsCall = null;
    last2EnteredQ  = null;
    last2EntryCall = null;
    quadrantUsed   = false;
    q5SeenFrom.clear();
    sessionTimers.forEach(id => { clearTimeout(id); clearInterval(id); });
    sessionTimers = [];
    clearInterval(sessionInterval);
    const footer = $('session-footer');
    if (footer) footer.innerHTML = `
      <div style="color:var(--gn);font-family:var(--fh);font-size:10px;letter-spacing:1px">
        ${reason==='manual'?'⏹ Análise pausada':'🏁 Encerrada'} · ${q5EntriesDone} entrada${q5EntriesDone!==1?'s':''}
      </div>`;
  }

  function stopSession() {
    lockedAssetId = null; q5Finish('manual'); sessionTimers=[]; sessionInterval=null; }

  function readSessionStrategyFromUI() {
    const sel = $('strategy-sel');
    const v   = (sel && sel.value) || 'claude_pro';
    const ok  = ['q5', 'alt', 'sniper', 'claude_pro', 'hard'];
    return ok.includes(v) ? v : 'claude_pro';
  }

  function secondsUntilNextM1Open(nowSec = Math.floor(Date.now() / 1000)) {
    if (nowSec % 60 === 0) return 0;
    return 60 - (nowSec % 60);
  }

  function clearHardTimer() {
    if (hardTimerId != null) {
      clearTimeout(hardTimerId);
      hardTimerId = null;
    }
  }

  function scheduleHardEntry() {
    clearHardTimer();
    if (!q5Running || sessionStrategy !== 'hard') return;
    const delayMs = Math.round(30000 + Math.random() * 60000);
    hardTimerId = setTimeout(() => {
      hardTimerId = null;
      hardAttemptEntry();
    }, delayMs);
  }

  async function hardAttemptEntry() {
    if (!q5Running || sessionStrategy !== 'hard') return;
    // Não abre nova operação enquanto a anterior não fechou.
    if (q5Executing || hardEnteredAt !== null) return;

    const waitSec = secondsUntilNextM1Open();
    if (waitSec > 0) {
      await new Promise(r => setTimeout(r, waitSec * 1000));
    }

    if (!q5Running || sessionStrategy !== 'hard') return;
    if (q5Executing || hardEnteredAt !== null) return;

    const nowSec     = Math.floor(Date.now() / 1000);
    const candleFrom = Math.floor(nowSec / 60) * 60;
    const isCall     = Math.random() < 0.5;
    hardEnteredAt    = candleFrom;
    hardEntryIsCall  = isCall;
    q5Executing      = true;
    try {
      await q5ExecuteEntry(isCall, 'Hard', 'HARD');
    } finally {
      q5Executing = false;
    }
  }

  function startSession() {
    sessionStrategy = readSessionStrategyFromUI();
    store.set({ cia_session_strategy: sessionStrategy });

    q5Running      = true;
    q5EntriesDone  = 0;
    sessionWins    = 0;
    sessionLosses  = 0;
    const wEl=$('score-win'),lEl=$('score-loss'),tEl=$('score-total');
    if(wEl){wEl.textContent='0';lEl.textContent='0';tEl.textContent='0';}
    q5EnteredQuad  = null;
    q5EntryIsCall  = null;
    q5Executing    = false;
    q5SeenFrom.clear();
    altEnteredAt   = null;
    altEntryIsCall = null;
    last2EnteredQ  = null;
    last2EntryCall = null;
    quadrantUsed   = false;
    sessionTimers  = [];
    clearHardTimer();
    hardEnteredAt   = null;
    hardEntryIsCall = null;
    // Reseta martingale ao iniciar nova sessão
    martingaleActive = false;
    lastTradeAmount  = martingaleBase;

    const slots = $('entry-slots');
    if (slots) slots.innerHTML = '';

    const footer = $('session-footer');
    if (footer) footer.innerHTML = `
      <div class="live-analysis-box" id="live-analysis-box">
        <div class="lab-header">
          <span class="spin" style="width:7px;height:7px;border-width:1.5px"></span>
          
        </div>
        <div class="lab-ticker" id="lab-ticker">Iniciando análise...</div>
      </div>`;

    setState('session');

    if (sessionStrategy === 'hard') {
      updateSessionTicker('Hard: aguarda 30–90s e entra no abrir da vela. Nova entrada só após fechar a anterior.');
      scheduleHardEntry();
      return;
    }

    const nowTs = Math.floor(Date.now()/1000);
    const pos   = posInQuadrant(nowTs);
    const rem   = 5 - pos;
    updateSessionTicker(`Vela ${pos+1}/5 do quadrante atual — ${rem} vela${rem>1?'s':''} para fechar quadrante`);
  }

  function runSilentAnalysis() { return new Promise(r => setTimeout(r, 400)); }

  // ══════════════════════════════════════════════════════════════════

  // ══════════════════════════════════════════════════════════════════
  // ── CLICK-CAPTURE SYSTEM ─────────────────────────────────────────
  // ══════════════════════════════════════════════════════════════════
  // User clicks the actual button on the platform — we intercept before
  // the event reaches the page and record coordinates + selector.

  // ── (Pin calibration system removed — SDK-only execution) ─────────

  async function executeEntry(isCall, _manualOverride = false, _skipSessionCheck = false) {
    if (!_manualOverride && !_skipSessionCheck && !q5Running) {
      console.warn('[Claude IA] executeEntry blocked — no active session');
      return { ok: false, error: 'Nenhuma sessão ativa' };
    }
    // ── Entrada 100% via SDK (via CustomEvent — bridge entre mundos) ──
    if (!sdkReady) {
      console.warn('[Claude IA] SDK não conectado');
      return { ok: false, error: 'SDK não conectado. Aguarde ou recarregue a página.' };
    }
    if (!currentActiveId) {
      return { ok: false, error: 'Ativo não detectado ainda.' };
    }

    try {
      const s      = await store.get(['cia_sdk_amount']);
      const raw    = Number(s.cia_sdk_amount);
      const amount = (raw >= 1 && raw <= 10000) ? raw : 5;
      lastTradeAmount = amount; // salva para push de resultado
      const useD   = false; // sempre Real
      const type   = 'digital';

      const dir  = isCall ? 'call' : 'put';
      const base = { activeId: currentActiveId, direction: dir, amount, useDemo: useD };

      // Tenta todos os tipos em ordem até um funcionar
      const sequence = ['digital'];

      let lastError = '';
      for (const t of sequence) {
        const r = await sdkBuy({ type: t, ...base });
        if (r.ok) {
          console.log('[Claude IA] Entrada via SDK (' + t + '):', r.id);
          return { ok: true, method: 'sdk-' + t, id: r.id };
        }
        console.warn('[Claude IA] ' + t + ' falhou:', r.error);
        lastError = r.error;
      }
      return { ok: false, error: lastError };
    } catch (e) {
      const msg = e?.message || String(e);
      console.warn('[Claude IA] executeEntry error:', msg);
      return { ok: false, error: msg };
    }
  }

  // ── Analysis ──────────────────────────────────────────────────────
  function runAnalysis() {
    setState('analyzing');
    const list = $('slist');
    list.innerHTML = STEPS.map((s,i) => `
      <div class="step" id="st${i}">
        <span class="sico">${s.icon}</span>
        <span class="slbl">${s.label}</span>
        <span class="sst" id="ss${i}">○</span>
      </div>`).join('');

    let cur=0;
    function tick() {
      if (cur>0) {
        $('st'+(cur-1))?.classList.replace('active','done');
        const p=$('ss'+(cur-1)); if(p) p.textContent='✓';
      }
      if (cur<STEPS.length) {
        $('st'+cur)?.classList.add('active');
        const st=$('ss'+cur); if(st) st.innerHTML='<span class="spin"></span>';
        const pct=Math.round(((cur+1)/STEPS.length)*100);
        $('pbar').style.width=pct+'%'; $('ppct').textContent=pct+'%';
        cur++; setTimeout(tick, cur<STEPS.length?700:1200);
      } else { showSignal(); }
    }
    setTimeout(tick,300);
  }

  // ── Signal ────────────────────────────────────────────────────────
  function showSignal() {
    const { isCall, assert } = generateSmartSignal();

    $('sig-dir').className  = 'sigdir '+(isCall?'call':'put');
    $('sig-arrow').textContent = isCall?'▲':'▼';
    $('sig-name').textContent  = isCall?'CALL':'PUT';
    const execBtn = $('btn-exec');
    execBtn.className   = 'btn-exec '+(isCall?'call':'put');
    execBtn.textContent = isCall?'▲  Confirmar CALL':'▼  Confirmar PUT';
    execBtn.dataset.call = isCall?'1':'0';
    execBtn.style.display = 'block';
    $('autonote').style.display = 'none';

    setState('signal');
    setTimeout(()=>{ $('sa-val').textContent=assert+'%'; $('sa-fil').style.width=assert+'%'; },200);

    if (autoMode) {
      execBtn.style.display = 'none';
      const note = $('autonote');
      note.style.cssText = 'display:flex;align-items:flex-start;gap:7px;border-radius:8px;padding:9px 11px;font-size:10px;font-weight:600;margin-top:9px;line-height:1.4;background:rgba(53,79,82,.15);border:1px solid rgba(53,79,82,.4);color:#6aacb2';
      note.innerHTML = '<span class="spin"></span>&nbsp;Executando entrada automática via CDP...';

      executeEntry(isCall).then(result => {
        if (result.ok) {
          note.style.background   = 'rgba(46,204,138,.1)';
          note.style.borderColor  = 'rgba(46,204,138,.3)';
          note.style.color        = '#2ecc8a';
          note.innerHTML = `✅ Entrada executada — ${isCall?'CALL':'PUT'}`;
          setTimeout(()=>setState('configured'),3500);
        } else {
          const needsReload = result.error?.includes('F5') || result.error?.includes('inválido') || result.error?.includes('invalidated');
          note.style.background   = 'rgba(224,80,96,.1)';
          note.style.borderColor  = 'rgba(224,80,96,.3)';
          note.style.color        = '#e05060';
          note.innerHTML = needsReload
            ? `🔄 Extensão foi recarregada.<br><strong>Pressione F5 para atualizar a página</strong> e tente novamente.`
            : `⚠️ ${result.error||'Erro desconhecido'}`;
          execBtn.style.display = 'block';
        }
      });
    }
  }

  // ── Bindings ──────────────────────────────────────────────────────

  // Gear / settings
  $('wgear').addEventListener('click', e => {
    e.stopPropagation();
    $('settings-overlay').classList.add('open');
  });
  $('settings-close').addEventListener('click', () => $('settings-overlay').classList.remove('open'));

  // SDK controls
  store.get(['cia_sdk_amount', 'cia_martingale_base']).then(s => {
    // Sempre restaura o valor BASE (não o dobrado do martingale)
    const rawBase = Number(s.cia_martingale_base);
    const rawAmt  = Number(s.cia_sdk_amount);
    // Base salvo tem prioridade; se não tiver, usa cia_sdk_amount ou 5
    const base  = (rawBase >= 1 && rawBase <= 10000) ? rawBase
                : (rawAmt  >= 1 && rawAmt  <= 10000) ? rawAmt : 5;
    // Ao carregar, sempre reseta para o valor base (ignora dobrado)
    store.set({ cia_sdk_amount: base, cia_martingale_base: base });
    const a1 = $('sdk-amount-inp'), a2 = $('main-amount-inp');
    if (a1) a1.value = base;
    if (a2) a2.value = base;
    // Inicializa martingale limpo
    martingaleBase   = base;
    lastTradeAmount  = base;
    martingaleActive = false;
    selectAccount();
  });
  function onAmountChange(val) {
    // Ignora mudanças disparadas pelo próprio martingale
    if (martingaleSuppressSync) return;
    const v = Number(val) || 5;
    const a1 = $('sdk-amount-inp'), a2 = $('main-amount-inp');
    if (a1) a1.value = v;
    if (a2) a2.value = v;
    store.set({ cia_sdk_amount: v, cia_martingale_base: v });
    // Atualiza base do martingale quando usuário muda o valor manualmente
    martingaleBase   = v;
    lastTradeAmount  = v;
    martingaleActive = false;
  }
  function selectAccount() {
    // Sempre Real — sem Demo
    sdkUseDemo = false;
    store.set({ cia_sdk_demo: false });
  }
  $('sdk-amount-inp')?.addEventListener('change', e => onAmountChange(e.target.value));
  $('main-amount-inp')?.addEventListener('change', e => onAmountChange(e.target.value));

  window.addEventListener('__cia_sdk_ready__', () => {
    const st = $('sdk-status');
    if (st) { st.className = 'status-badge ok'; st.innerHTML = '<span class="status-dot"></span>Claude Pro Calibrado'; }
  });
  window.addEventListener('__cia_sdk_error__', e => {
    const st = $('sdk-status');
    if (st) { st.className = 'status-badge err'; st.innerHTML = '<span class="status-dot"></span>' + (e.detail?.error || 'Erro na conexão'); }
  });
  // Welcome screen → run scan and continue only if OK
  $('btn-start-welcome').addEventListener('click', () => {
    const report = runStartupScan({ forceModal: true });
    if (report.issues.length) return;
    setState('configured');
  });

  // Analysis start → Q5 session
  $('btn-analyze').addEventListener('click', () => {
    selectedEntryMin = 1; // Lite: fixed M1
    lockedAssetId = currentActiveId;
    // Update asset display
    if (selectedAsset) {
      ['anal-asset','sig-asset-name','sig-meta-asset'].forEach(id => {
        const el=$(id); if(el) el.textContent=selectedAsset;
      });
    }
    const entryEl=$('sig-entry-time'); if(entryEl) entryEl.textContent=selectedEntryMin+' min';
    startSession();
  });

  $('btn-stop-session').addEventListener('click', () => {
    stopSession();
    setState('configured');
  });

  // Manual signal close/new
  $('btn-cls-sig').addEventListener('click', () => setState('configured'));
  $('btn-new').addEventListener('click',     () => { stopSession(); setState('configured'); });

  // Manual confirm entry button
  $('btn-exec').addEventListener('click', async e => {
    const isCall = e.currentTarget.dataset.call === '1';
    e.currentTarget.disabled = true;
    e.currentTarget.textContent = 'Executando...';
    const result = await executeEntry(isCall, true); // manual override
    if (result.ok) setState('configured');
    else {
      e.currentTarget.disabled = false;
      e.currentTarget.textContent = isCall ? '▲  Confirmar CALL' : '▼  Confirmar PUT';
      const note = $('autonote');
      note.style.cssText = 'display:flex;background:rgba(224,80,96,.1);border:1px solid rgba(224,80,96,.3);color:#e05060;border-radius:2px;padding:9px;font-size:10px;margin-top:9px';
      note.textContent = '⚠️ ' + (result.error || 'Erro ao clicar');
    }
  });

  function syncStrategyPickerUI() {
    const sel = $('strategy-sel'), lbl = $('strategy-dd-label');
    if (!sel || !lbl) return;
    const opt = sel.options[sel.selectedIndex];
    lbl.textContent = opt ? opt.text : 'Claude Pro';
    shadow.querySelectorAll('.strategy-dd-item').forEach(li => {
      li.classList.toggle('is-active', li.dataset.value === sel.value);
    });
  }

  const strategyDd     = $('strategy-dd');
  const strategyDdBtn  = $('strategy-dd-btn');
  const strategyDdMenu = $('strategy-dd-menu');
  let strategyDdOpen   = false;

  function closeStrategyDd() {
    strategyDdOpen = false;
    if (strategyDdMenu) strategyDdMenu.hidden = true;
    if (strategyDdBtn) {
      strategyDdBtn.classList.remove('open');
      strategyDdBtn.setAttribute('aria-expanded', 'false');
    }
  }

  function openStrategyDd() {
    strategyDdOpen = true;
    if (strategyDdMenu) strategyDdMenu.hidden = false;
    if (strategyDdBtn) {
      strategyDdBtn.classList.add('open');
      strategyDdBtn.setAttribute('aria-expanded', 'true');
    }
  }

  if (strategyDdBtn) {
    strategyDdBtn.addEventListener('click', e => {
      e.stopPropagation();
      if (strategyDdOpen) closeStrategyDd();
      else openStrategyDd();
    });
  }
  shadow.querySelectorAll('.strategy-dd-item').forEach(li => {
    li.addEventListener('click', e => {
      e.stopPropagation();
      const v = li.dataset.value;
      const sel = $('strategy-sel');
      if (!sel) return;
      if (sel.value !== v) {
        sel.value = v;
        sel.dispatchEvent(new Event('change', { bubbles: true }));
      } else {
        syncStrategyPickerUI();
      }
      closeStrategyDd();
    });
  });
  document.documentElement.addEventListener('click', e => {
    if (!strategyDdOpen || !strategyDd) return;
    if (e.composedPath().includes(strategyDd)) return;
    closeStrategyDd();
  });

  $('strategy-sel').addEventListener('change', e => {
    store.set({ cia_session_strategy: e.target.value });
    syncStrategyPickerUI();
  });

  function parseBrowserInfo() {
    const ua = navigator.userAgent || '';
    let name = 'Desconhecido';
    let major = null;

    const edge = ua.match(/Edg\/(\d+)/);
    const opera = ua.match(/OPR\/(\d+)/);
    const chrome = ua.match(/Chrome\/(\d+)/);
    const firefox = ua.match(/Firefox\/(\d+)/);
    const safari = (!chrome && !edge && !opera) ? ua.match(/Version\/(\d+).+Safari\//) : null;

    if (edge)      { name = 'Microsoft Edge'; major = Number(edge[1]); }
    else if (opera){ name = 'Opera'; major = Number(opera[1]); }
    else if (chrome){ name = 'Google Chrome/Chromium'; major = Number(chrome[1]); }
    else if (firefox){ name = 'Mozilla Firefox'; major = Number(firefox[1]); }
    else if (safari){ name = 'Safari'; major = Number(safari[1]); }

    return { name, major, ua };
  }

  function getOsInfo() {
    const ua = navigator.userAgent || '';
    if (ua.includes('Windows NT 6.1')) return { name: 'Windows 7', isOld: true };
    if (ua.includes('Windows NT 6.3')) return { name: 'Windows 8.1', isOld: true };
    if (ua.includes('Windows NT 10.0')) return { name: 'Windows 10/11', isOld: false };
    if (ua.includes('Mac OS X')) return { name: 'macOS', isOld: false };
    if (ua.includes('Linux')) return { name: 'Linux', isOld: false };
    if (ua.includes('Android')) return { name: 'Android', isOld: false };
    return { name: 'SO não identificado', isOld: false };
  }

  function buildStartupScanReport() {
    const browser = parseBrowserInfo();
    const os = getOsInfo();
    const ua = browser.ua || '';
    const issues = [];
    const compatBrowsers = 'Chrome, Edge, Brave e Opera (Chromium) em versões recentes.';
    const isChromiumFamily = /Chrome\/|Chromium\/|Edg\/|OPR\//.test(ua);

    if (!location.hostname.endsWith('avalonbroker.com')) {
      issues.push({
        code: 'wrong_host',
        title: 'Site incompatível',
        detail: 'A extensão só funciona em páginas da Broker10 (*.avalonbroker.com).',
      });
    }
    if (!window.chrome?.runtime || !window.chrome?.storage?.local) {
      issues.push({
        code: 'chrome_api_missing',
        title: 'APIs da extensão indisponíveis',
        detail: 'As APIs chrome.runtime/chrome.storage não estão acessíveis neste navegador.',
      });
    }
    if (!isChromiumFamily) {
      issues.push({
        code: 'browser_unsupported',
        title: `Navegador incompatível: ${browser.name}`,
        detail: `Navegador atual: ${browser.name}. Compatíveis: ${compatBrowsers}`,
      });
    }
    if (isChromiumFamily && browser.major && browser.major < 88) {
      issues.push({
        code: 'browser_too_old',
        title: 'Navegador muito antigo',
        detail: `Versão atual: ${browser.major}. É necessário Chromium 88+ (recomendado 110+).`,
      });
    }
    if (os.isOld) {
      issues.push({
        code: 'os_too_old',
        title: `Sistema operacional antigo: ${os.name}`,
        detail: `${os.name} tem suporte limitado para recursos modernos da extensão. Atualize para Windows 10/11 ou use um ambiente mais recente.`,
      });
    }
    // Não validar ponte WS aqui para evitar falso positivo:
    // em alguns contextos/tempos de carregamento, essa checagem pode falhar
    // mesmo com a extensão funcional.

    return { browser, os, issues };
  }

  function showCompatibilityModal(report) {
    if (compatModalOpen) return;
    if (!report.issues.length) return;
    compatModalOpen = true;

    const old = document.getElementById('__cia_compat__');
    if (old) old.remove();

    const ov = document.createElement('div');
    ov.id = '__cia_compat__';
    ov.style.cssText = [
      'position:fixed','inset:0','z-index:2147483647',
      'display:flex','align-items:center','justify-content:center',
      'background:rgba(0,0,0,.84)','backdrop-filter:blur(6px)',
      "font-family:'Outfit',system-ui,sans-serif",'padding:20px'
    ].join(';');

    const items = report.issues.map(i => `
      <div style="background:#0e1535;border:1px solid rgba(255,59,92,.28);border-radius:10px;padding:10px 12px;margin-bottom:9px">
        <div style="font-size:12px;font-weight:700;color:#ff8297;margin-bottom:3px">${i.title}</div>
        <div style="font-size:11px;color:#a0b4d8;line-height:1.5">${i.detail}</div>
      </div>
    `).join('');

    ov.innerHTML = `
      <div style="background:#05091a;border:1px solid rgba(255,59,92,.34);border-radius:18px;padding:24px;width:100%;max-width:520px;max-height:90vh;overflow:auto;box-shadow:0 24px 80px rgba(0,0,0,.9)">
        <div style="font-size:20px;font-weight:800;color:#ff6b84;margin-bottom:6px">Ambiente incompatível</div>
        <div style="font-size:12px;color:#a0b4d8;line-height:1.6;margin-bottom:14px">
          Detectamos problemas que impedem a extensão de operar corretamente.
        </div>
        <div style="font-size:11px;color:#4a6090;margin-bottom:10px">
          Navegador atual: ${report.browser.name}${report.browser.major ? ' ' + report.browser.major : ''} · Sistema: ${report.os.name}
        </div>
        ${items}
        <button id="__cia_compat_btn__" style="width:100%;margin-top:6px;padding:13px;border-radius:12px;border:none;background:linear-gradient(160deg,#1a4aff,#0d2acc);color:#fff;font-size:14px;font-weight:700;cursor:pointer">
          Entendi
        </button>
      </div>
    `;
    document.documentElement.appendChild(ov);
    document.getElementById('__cia_compat_btn__').addEventListener('click', () => {
      compatModalOpen = false;
      ov.remove();
    });
  }

  function runStartupScan({ forceModal = false } = {}) {
    const report = buildStartupScanReport();
    envFatalIssues = report.issues;
    envScanDone = true;
    checkAnalyzeReady();
    if (forceModal && report.issues.length) showCompatibilityModal(report);
    return report;
  }

  $('auto-chk').addEventListener('change', e => { autoMode=e.target.checked; store.set({cia_auto:autoMode}); checkAnalyzeReady(); });
  $('martingale-chk').addEventListener('change', e => {
    martingaleEnabled = e.target.checked;
    store.set({ cia_martingale: martingaleEnabled });
    // Ao desligar, reseta o valor de volta ao base
    if (!martingaleEnabled && martingaleActive) {
      martingaleActive = false;
      lastTradeAmount  = martingaleBase;
      martingaleSuppressSync = true;
      store.set({ cia_sdk_amount: martingaleBase });
      const a1 = $('sdk-amount-inp'), a2 = $('main-amount-inp');
      if (a1) a1.value = martingaleBase;
      if (a2) a2.value = martingaleBase;
      martingaleSuppressSync = false;
    }
  });

  $('lurl').addEventListener('change', e => store.set({ cia_live_url: e.target.value }));
  $('btn-live').addEventListener('click', () => {
    const u = $('lurl').value.trim();
    if (u) window.open(u, '_blank', 'noopener'); else $('lurl').focus();
  });

  chrome.runtime.onMessage.addListener(msg => {
    if (msg.type === 'toggle') panel.classList.toggle('hidden');
  });

  // ── Init ──────────────────────────────────────────────────────────
  // ── Terms of Use ──────────────────────────────────────────────────
  function showTermsIfNeeded() {
    // Check cookie first (faster), then chrome.storage
    const cookieAccepted = document.cookie.split(';').some(c => c.trim() === 'cia_terms=1');
    if (cookieAccepted) return;

    store.get(['cia_terms_accepted']).then(r => {
      if (r.cia_terms_accepted) return;

      // Build full-page overlay injected into document (outside shadow DOM)
      const ov = document.createElement('div');
      ov.id = '__cia_terms__';
      ov.style.cssText = [
        'position:fixed','inset:0','z-index:2147483647',
        'display:flex','align-items:center','justify-content:center',
        'background:rgba(0,0,0,.82)','backdrop-filter:blur(6px)',
        "font-family:'Outfit',system-ui,sans-serif",
        'padding:20px',
      ].join(';');

      ov.innerHTML = `
        <div style="
          background:#05091a;border:1px solid rgba(50,90,220,.35);border-radius:18px;
          padding:28px 24px;width:100%;max-width:420px;
          box-shadow:0 24px 80px rgba(0,0,0,.9),0 0 0 1px rgba(40,75,200,.15);
          display:flex;flex-direction:column;align-items:center;
          max-height:90vh;overflow:hidden;
        ">
          <!-- icon -->
          <div style="
            width:54px;height:54px;border-radius:14px;margin-bottom:14px;
            background:rgba(26,74,255,.12);border:1px solid rgba(50,90,220,.35);
            display:flex;align-items:center;justify-content:center;flex-shrink:0;
          ">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#6090ff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14 2 14 8 20 8"/>
              <line x1="16" y1="13" x2="8" y2="13"/>
              <line x1="16" y1="17" x2="8" y2="17"/>
            </svg>
          </div>

          <div style="font-size:20px;font-weight:800;color:#e8f0ff;margin-bottom:5px;text-align:center">Termos de Uso</div>
          <div style="font-size:12px;color:#4a6090;margin-bottom:16px;text-align:center">Leia e aceite antes de continuar</div>

          <!-- scroll area -->
          <div style="
            width:100%;overflow-y:auto;flex:1;
            background:#0e1535;border:1px solid rgba(50,90,220,.2);border-radius:12px;
            padding:16px;margin-bottom:16px;max-height:340px;
          ">
            <p style="font-size:11px;font-weight:700;color:#6090ff;margin:0 0 6px">1. Responsabilidade do Usuário</p>
            <p style="font-size:11px;color:#a0b4d8;line-height:1.65;margin:0 0 12px">Ao utilizar esta ferramenta, o usuário declara ter plena ciência de que toda e qualquer decisão de operação financeira é de sua exclusiva responsabilidade. O uso da extensão, dos sinais gerados e das funcionalidades disponibilizadas é feito por conta e risco do próprio usuário.</p>

            <p style="font-size:11px;font-weight:700;color:#6090ff;margin:0 0 6px">2. Isenção de Responsabilidade do Fornecedor</p>
            <p style="font-size:11px;color:#a0b4d8;line-height:1.65;margin:0 0 12px">O desenvolvedor e/ou fornecedor desta ferramenta não possui qualquer vínculo, responsabilidade ou obrigação com relação às operações realizadas pelo usuário. O fornecedor não é corretora, assessor financeiro, nem gestor de investimentos.</p>

            <p style="font-size:11px;font-weight:700;color:#6090ff;margin:0 0 6px">3. Perdas Financeiras</p>
            <p style="font-size:11px;color:#a0b4d8;line-height:1.65;margin:0 0 12px">Quaisquer perdas financeiras, prejuízos, danos diretos ou indiretos decorrentes do uso desta ferramenta são de responsabilidade exclusiva do usuário. O usuário reconhece que mercados financeiros envolvem risco de perda total do capital investido e que nenhum resultado passado garante resultados futuros.</p>

            <p style="font-size:11px;font-weight:700;color:#6090ff;margin:0 0 6px">4. Natureza da Ferramenta</p>
            <p style="font-size:11px;color:#a0b4d8;line-height:1.65;margin:0 0 12px">Esta extensão é uma ferramenta de automação e análise técnica. Não constitui recomendação de investimento, consultoria financeira ou garantia de lucro. O usuário é o único responsável pela forma como utiliza os sinais e recursos disponibilizados.</p>

            <p style="font-size:11px;font-weight:700;color:#6090ff;margin:0 0 6px">5. Aceitação</p>
            <p style="font-size:11px;color:#a0b4d8;line-height:1.65;margin:0">Ao clicar em "Aceitar e Continuar", o usuário confirma que leu, compreendeu e concorda integralmente com estes termos, isentando o fornecedor de qualquer responsabilidade sobre o uso da ferramenta e seus resultados.</p>
          </div>

          <button id="__cia_terms_btn__" style="
            width:100%;padding:15px;border-radius:12px;border:none;
            background:linear-gradient(160deg,#1a4aff,#0d2acc);
            color:#fff;font-size:15px;font-weight:700;cursor:pointer;
            font-family:'Outfit',system-ui,sans-serif;
            box-shadow:0 5px 20px rgba(26,74,255,.4);
            letter-spacing:.3px;transition:all .2s;flex-shrink:0;
          ">Aceitar e Continuar</button>

          <p style="font-size:10px;color:#4a6090;margin-top:10px;text-align:center;line-height:1.5">
            Ao continuar, você concorda com todos os termos acima.
          </p>
        </div>`;

      document.documentElement.appendChild(ov);

      // Inject Outfit font if needed
      if (!document.getElementById('__cia_outfit_font__')) {
        const lnk = document.createElement('link');
        lnk.id = '__cia_outfit_font__';
        lnk.rel = 'stylesheet';
        lnk.href = 'https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&display=swap';
        document.head.appendChild(lnk);
      }

      document.getElementById('__cia_terms_btn__').addEventListener('click', () => {
        // Save to cookie (10 years) + chrome.storage
        const exp = new Date(Date.now() + 10 * 365 * 24 * 60 * 60 * 1000).toUTCString();
        document.cookie = 'cia_terms=1; expires=' + exp + '; path=/; SameSite=Lax';
        store.set({ cia_terms_accepted: true });
        ov.style.opacity = '0';
        ov.style.transition = 'opacity .35s';
        setTimeout(() => ov.remove(), 350);
      });
    });
  }

  // ── Comandos recebidos do membros.html (via background.js) ──────────────
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    // Status da conexão
    if (msg.type === 'BROKER_STATUS') {
      const bals = window.__cia_sdk_balances?.() || null;
      sendResponse({
        connected:  sdkReady,
        balances:   bals,
        asset:      currentActiveId ? (activeMap[currentActiveId]?.name || null) : null,
        botRunning: q5Running,
      });
      return false;
    }

    // Iniciar bot
    if (msg.type === 'START_BOT') {
      const cfg = msg.config || {};
      const ps  = [];
      if (cfg.amount && Number(cfg.amount) >= 1) {
        const amt = Number(cfg.amount);
        lastTradeAmount = amt;
        ps.push(store.set({ cia_sdk_amount: amt }));
      }
      if (typeof cfg.autoMode === 'boolean') {
        autoMode = cfg.autoMode;
        const chk = $('auto-chk');
        if (chk) chk.checked = autoMode;
      }
      if (cfg.strategy && ['q5','alt','sniper','claude_pro','hard'].includes(cfg.strategy)) {
        const ss = $('strategy-sel');
        if (ss) {
          ss.value = cfg.strategy;
          ss.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
      Promise.all(ps).then(() => {
        if (!q5Running) startSession();
        sendResponse({ ok: true });
      });
      return true; // async
    }

    // Parar bot
    if (msg.type === 'STOP_BOT') {
      if (q5Running) stopSession();
      sendResponse({ ok: true });
      return false;
    }

    return false;
  });

  async function init() {
    await loadPos();
    chrome.storage.local.remove('cia_panel_shown');
    const r = await store.get(['cia_live_url','cia_auto','cia_entry_min','cia_session_strategy']);
    if (r.cia_live_url) $('lurl').value = r.cia_live_url;
    if (r.cia_auto) { autoMode=true; $('auto-chk').checked=true; }
    const st = r.cia_session_strategy;
    if (st && ['q5','alt','sniper','claude_pro','hard'].includes(st)) {
      const ss = $('strategy-sel');
      if (ss) ss.value = st;
    }
    syncStrategyPickerUI();

    // Restore trade config
    initTradeConfig();
    selectedEntryMin = 1; // Lite: always M1

    setState('welcome');
    setTimeout(() => {
      panel.classList.remove('hidden');
      // Recalcula posição agora que o painel está visível e tem dimensões reais
      loadPos();
      showTermsIfNeeded();
    }, 400);
  }
  init();
})();
