import {
  ClientSdk,
  SsidAuthMethod,
  TurboOptionsDirection,
  BinaryOptionsDirection,
  DigitalOptionsDirection,
  BlitzOptionsDirection,
} from '@quadcode-tech/client-sdk-js';

const API_URL     = 'wss://ws.trade.avalonbroker.com/echo/websocket';
const PLATFORM_ID = 482;

let sdk         = null;
let demoBalance = null;
let realBalance = null;
let initPending = false;

async function initSdk(ssid) {
  if (sdk || initPending) return;
  initPending = true;

  try {
    console.log('[Claude SDK] Conectando... SSID:', ssid.slice(0, 8) + '...');
    sdk = await ClientSdk.create(API_URL, PLATFORM_ID, new SsidAuthMethod(ssid));
    window.__cia_sdk__ = sdk;

    const balFacade = await sdk.balances();
    const bals      = balFacade.getBalances();
    demoBalance     = bals.find(b => b.type === 'demo') || null;
    realBalance     = bals.find(b => b.type === 'real') || null;

    window.dispatchEvent(new CustomEvent('__cia_sdk_ready__', {
      detail: {
        demo: demoBalance ? { id: demoBalance.id, amount: demoBalance.amount, currency: demoBalance.currency } : null,
        real: realBalance ? { id: realBalance.id, amount: realBalance.amount, currency: realBalance.currency } : null,
      },
    }));

    console.log('[Claude SDK] ✅ Pronto! Demo:', demoBalance?.amount, '| Real:', realBalance?.amount);
  } catch (err) {
    initPending = false;
    sdk = null;
    console.error('[Claude SDK] ❌ Falha na conexão:', err.message);
    window.dispatchEvent(new CustomEvent('__cia_sdk_error__', { detail: { error: err.message } }));
  }
}

// ── SSID: busca em múltiplos lugares ────────────────────────────────────────

function findSsid() {
  // 1. Cookies — nomes comuns em plataformas Quadcode
  const cookieMap = {};
  document.cookie.split(';').forEach(c => {
    const [k, ...v] = c.trim().split('=');
    if (k) cookieMap[k.trim()] = v.join('=');
  });
  for (const name of ['ssid', 'session_id', 'token', 'auth_token', 'userSsid', 'user_ssid', 'session']) {
    if (cookieMap[name] && cookieMap[name].length > 8) {
      console.log('[Claude SDK] SSID encontrado em cookie:', name);
      return decodeURIComponent(cookieMap[name]);
    }
  }

  // 2. localStorage
  try {
    for (const key of ['ssid', 'session', 'token', 'auth', 'userSsid', 'user_ssid', 'user_token']) {
      const val = localStorage.getItem(key);
      if (val && val.length > 8) {
        console.log('[Claude SDK] SSID encontrado em localStorage:', key);
        return val;
      }
    }
  } catch {}

  // 3. sessionStorage
  try {
    for (const key of ['ssid', 'session', 'token', 'auth', 'userSsid']) {
      const val = sessionStorage.getItem(key);
      if (val && val.length > 8) {
        console.log('[Claude SDK] SSID encontrado em sessionStorage:', key);
        return val;
      }
    }
  } catch {}

  // 4. Variáveis globais da página
  for (const key of ['ssid', '__ssid__', '_ssid', 'userSsid', 'SESSION_ID', 'AUTH_TOKEN']) {
    try {
      const val = window[key];
      if (typeof val === 'string' && val.length > 8) {
        console.log('[Claude SDK] SSID encontrado em window.' + key);
        return val;
      }
    } catch {}
  }

  console.warn('[Claude SDK] SSID não encontrado — aguardando mensagem WS...');
  return null;
}

// Tenta imediatamente ao carregar
const immediatesSsid = findSsid();
if (immediatesSsid) {
  initSdk(immediatesSsid);
} else {
  // Tenta novamente após 2s (página pode não ter carregado tudo ainda)
  setTimeout(() => {
    if (!sdk && !initPending) {
      const delayed = findSsid();
      if (delayed) initSdk(delayed);
    }
  }, 2000);
}

// Recebe SSID interceptado pelo ws_interceptor.js (mensagem WS de autenticação)
window.addEventListener('__cia_ssid__', e => {
  if (e.detail?.ssid && !sdk && !initPending) initSdk(e.detail.ssid);
});

// Reconecta automaticamente quando o WebSocket do broker fechar
window.addEventListener('__cia_ws_closed__', () => {
  if (!sdk) return;
  console.warn('[Claude SDK] WebSocket fechado — reconectando em 3s...');
  sdk = null;
  initPending = false;
  setTimeout(() => {
    const ssid = findSsid() || window.__cia_ssid__;
    if (ssid && !sdk && !initPending) initSdk(ssid);
  }, 3000);
});

// ── Helpers ──────────────────────────────────────────────────────────────────

function getBalance(useDemo) {
  return useDemo ? demoBalance : realBalance;
}

// ── Trade execution ──────────────────────────────────────────────────────────

window.__cia_sdk_buy_turbo = async function({ activeId, direction, amount, useDemo = true }) {
  if (!sdk) return { ok: false, error: 'SDK não conectado' };
  try {
    const turbo  = await sdk.turboOptions();
    const now    = sdk.currentTime();
    const active = turbo.getActives().find(a => a.id === activeId && a.canBeBoughtAt(now));
    if (!active) return { ok: false, error: `Ativo ${activeId} indisponível para turbo` };

    const avail = (await active.instruments()).getAvailableForBuyAt(now);
    const inst  = avail.find(i => i.durationRemainingForPurchase(now) > 3000);
    if (!inst) return { ok: false, error: 'Nenhum instrumento turbo disponível' };

    const bal = getBalance(useDemo);
    if (!bal) return { ok: false, error: `Saldo ${useDemo ? 'demo' : 'real'} não encontrado` };

    const dir   = direction === 'call' ? TurboOptionsDirection.Call : TurboOptionsDirection.Put;
    const order = await turbo.buy(inst, dir, amount, bal);
    console.log('[Claude SDK] Turbo aberto:', order.id, direction.toUpperCase(), amount);
    return { ok: true, id: order.id };
  } catch (err) {
    return { ok: false, error: err.message };
  }
};

window.__cia_sdk_buy_binary = async function({ activeId, direction, amount, useDemo = true }) {
  if (!sdk) return { ok: false, error: 'SDK não conectado' };
  try {
    const binary = await sdk.binaryOptions();
    const now    = sdk.currentTime();
    const active = binary.getActives().find(a => a.id === activeId && a.canBeBoughtAt(now));
    if (!active) return { ok: false, error: `Ativo ${activeId} indisponível para binary` };

    const avail = (await active.instruments()).getAvailableForBuyAt(now);
    const inst  = avail.find(i => i.durationRemainingForPurchase(now) > 3000);
    if (!inst) return { ok: false, error: 'Nenhum instrumento binary disponível' };

    const bal = getBalance(useDemo);
    if (!bal) return { ok: false, error: `Saldo ${useDemo ? 'demo' : 'real'} não encontrado` };

    const dir   = direction === 'call' ? BinaryOptionsDirection.Call : BinaryOptionsDirection.Put;
    const order = await binary.buy(inst, dir, amount, bal);
    console.log('[Claude SDK] Binary aberto:', order.id, direction.toUpperCase(), amount);
    return { ok: true, id: order.id };
  } catch (err) {
    return { ok: false, error: err.message };
  }
};

window.__cia_sdk_buy_digital = async function({ activeId, direction, amount, period = 60, useDemo = true }) {
  if (!sdk) return { ok: false, error: 'SDK não conectado' };
  try {
    const digital     = await sdk.digitalOptions();
    const now         = sdk.currentTime();
    const underlyings = digital.getUnderlyingsAvailableForTradingAt(now);
    const under       = underlyings.find(u => u.activeId === activeId);
    if (!under) return { ok: false, error: `Ativo ${activeId} indisponível para digital` };

    const avail = (await under.instruments()).getAvailableForBuyAt(now);
    const inst  = avail.find(i => i.period === period && i.durationRemainingForPurchase(now) > 1000)
               || avail.find(i => i.durationRemainingForPurchase(now) > 1000);
    if (!inst) return { ok: false, error: 'Nenhum instrumento digital disponível' };

    const bal = getBalance(useDemo);
    if (!bal) return { ok: false, error: `Saldo ${useDemo ? 'demo' : 'real'} não encontrado` };

    const dir   = direction === 'call' ? DigitalOptionsDirection.Call : DigitalOptionsDirection.Put;
    const order = await digital.buySpotStrike(inst, dir, amount, bal);
    console.log('[Claude SDK] Digital aberto:', order.id, direction.toUpperCase(), amount);
    return { ok: true, id: order.id };
  } catch (err) {
    return { ok: false, error: err.message };
  }
};

window.__cia_sdk_buy_blitz = async function({ direction, amount, useDemo = true }) {
  if (!sdk) return { ok: false, error: 'SDK não conectado' };
  try {
    const blitz  = await sdk.blitzOptions();
    const now    = sdk.currentTime();
    const active = blitz.getActives().find(a => a.canBeBoughtAt(now));
    if (!active) return { ok: false, error: 'Nenhum ativo blitz disponível' };

    const expirationSize = active.expirationTimes[0];
    const bal            = getBalance(useDemo);
    if (!bal) return { ok: false, error: `Saldo ${useDemo ? 'demo' : 'real'} não encontrado` };

    const dir   = direction === 'call' ? BlitzOptionsDirection.Call : BlitzOptionsDirection.Put;
    const order = await blitz.buy(active, dir, expirationSize, amount, bal);
    console.log('[Claude SDK] Blitz aberto:', order.id, direction.toUpperCase(), amount);
    return { ok: true, id: order.id };
  } catch (err) {
    return { ok: false, error: err.message };
  }
};

window.__cia_sdk_balances = function() {
  if (!sdk) return null;
  return {
    demo: demoBalance ? { amount: demoBalance.amount, currency: demoBalance.currency } : null,
    real: realBalance ? { amount: realBalance.amount, currency: realBalance.currency } : null,
  };
};

// ── Bridge: recebe pedidos do content.js (mundo isolado) via CustomEvent ─────
// content.js não pode chamar funções do MAIN world diretamente,
// então usamos eventos como canal de comunicação entre os dois mundos.

window.addEventListener('__cia_sdk_buy__', async (e) => {
  const { requestId, type, activeId, direction, amount, useDemo, period } = e.detail;
  let result;

  try {
    if (!sdk) {
      result = { ok: false, error: 'SDK não conectado' };
    } else if (type === 'digital') {
      result = await window.__cia_sdk_buy_digital({ activeId, direction, amount, period: period || 60, useDemo });
    } else if (type === 'binary') {
      result = await window.__cia_sdk_buy_binary({ activeId, direction, amount, useDemo });
    } else if (type === 'blitz') {
      result = await window.__cia_sdk_buy_blitz({ direction, amount, useDemo });
    } else {
      result = await window.__cia_sdk_buy_turbo({ activeId, direction, amount, useDemo });
    }
  } catch (err) {
    result = { ok: false, error: err.message };
  }

  window.dispatchEvent(new CustomEvent('__cia_sdk_result__', {
    detail: { requestId, ...result },
  }));
});
