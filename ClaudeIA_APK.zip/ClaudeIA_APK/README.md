# Claude IA Bot — Android APK

## O que é este projeto

Aplicativo Android que transforma a extensão **Claude IA** de daytrade automático em um app nativo. Permite:

- ✅ Rodar o bot em **segundo plano** enquanto você assiste YouTube
- 🔔 Receber **notificações nativas** de WIN e LOSS com valor e lucro
- 🛑 Configurar **Stop Loss** (ex: R$ 30 de perda máxima)
- 🏆 Configurar **Stop Win** (ex: R$ 50 de lucro alvo)
- 📈 **Martingale** configurável
- 🎯 Escolha de estratégia: Claude Pro, Q5, ALT, SNIPER, HARD

---

## Como compilar o APK

### Opção 1 — Android Studio (Recomendado)

1. Instale o [Android Studio](https://developer.android.com/studio)
2. Abra a pasta `ClaudeIA_APK` como projeto
3. Aguarde o Gradle sincronizar
4. Vá em **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. O APK estará em `app/build/outputs/apk/debug/app-debug.apk`

### Opção 2 — Linha de Comando

```bash
# Linux/Mac
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

APK gerado em: `app/build/outputs/apk/debug/app-debug.apk`

---

## Como instalar no celular

1. Copie o `app-debug.apk` para o celular
2. No celular: **Configurações → Segurança → Fontes desconhecidas → Ativar**
3. Abra o arquivo APK e instale

---

## Como usar

1. Abra o app **Claude IA Bot**
2. Toque em **⚙️ Configurações** e configure:
   - Stop Loss (perda máxima em R$)
   - Stop Win (lucro alvo em R$)
   - Valor de entrada por operação
   - Estratégia preferida
3. Toque em **🌐 Abrir Broker** — faça login na Avalon Broker
4. Toque em **▶ Iniciar Bot**
5. Toque em **🎬 Ocultar / BG** — agora você pode assistir YouTube!
6. As notificações chegam automaticamente:
   - ✅ **WIN** — com valor e lucro
   - ❌ **LOSS** — com valor perdido
   - 🛑 **STOP LOSS** — bot parado automaticamente
   - 🏆 **STOP WIN** — bot parado automaticamente

---

## Arquitetura

```
MainActivity.java          — UI principal + WebView + controles
BotForegroundService.java  — Serviço em background (permite minimizar)
SettingsActivity.java      — Tela de configurações
BotBridge (inner class)    — Ponte JS → Java para capturar resultados

assets/
  content.js        — Lógica principal do bot (estratégias Q5/ALT/HARD)
  ws_interceptor.js — Interceptor de WebSocket da corretora
  sdk-bundle.js     — SDK da corretora
  sdk-bridge.js     — Bridge do SDK
```

---

## Observação importante

O app abre a Avalon Broker (`trade.avalonbroker.com`) dentro de um WebView e injeta os scripts automaticamente. **Você precisa fazer login na corretora** dentro do app antes de iniciar o bot.

---

*Claude IA Bot v7.0.0 — Ferramenta de automação. Não constitui recomendação de investimento.*
